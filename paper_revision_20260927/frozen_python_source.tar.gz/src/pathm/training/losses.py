from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import Tensor, nn


def soft_dice_loss(logits: Tensor, targets: Tensor, epsilon: float = 1e-6) -> Tensor:
    probabilities = torch.sigmoid(logits)
    intersection = (probabilities * targets).sum(dim=(1, 2, 3))
    denominator = probabilities.sum(dim=(1, 2, 3)) + targets.sum(dim=(1, 2, 3))
    return 1.0 - ((2.0 * intersection + epsilon) / (denominator + epsilon))


def center_heatmap_focal_loss(
    logits: Tensor,
    targets: Tensor,
    alpha: float = 2.0,
    beta: float = 4.0,
    epsilon: float = 1e-4,
) -> Tensor:
    """CenterNet-style focal loss normalized by the number of object centers."""
    probabilities = torch.sigmoid(logits.float()).clamp(epsilon, 1.0 - epsilon)
    float_targets = targets.float()
    positive_mask = float_targets.eq(1.0)
    negative_mask = float_targets.lt(1.0)
    negative_weights = (1.0 - float_targets).pow(beta)
    positive_loss = (
        torch.log(probabilities) * (1.0 - probabilities).pow(alpha) * positive_mask
    ).sum(dim=(1, 2, 3))
    negative_loss = (
        torch.log(1.0 - probabilities)
        * probabilities.pow(alpha)
        * negative_weights
        * negative_mask
    ).sum(dim=(1, 2, 3))
    positive_count = positive_mask.sum(dim=(1, 2, 3)).clamp_min(1)
    return -(positive_loss + negative_loss) / positive_count


class MixedTaskLoss(nn.Module):
    """Use focal heatmap loss for detection and BCE+Dice for segmentation."""

    DETECTION_ID = 0
    SEGMENTATION_ID = 1

    def forward(self, logits: Tensor, targets: Tensor, operation_ids: Tensor) -> Tensor:
        if logits.shape != targets.shape:
            raise ValueError(f"Logit shape {logits.shape} does not match target {targets.shape}")
        detection = center_heatmap_focal_loss(logits, targets)
        segmentation = F.binary_cross_entropy_with_logits(
            logits, targets, reduction="none"
        ).mean(dim=(1, 2, 3)) + soft_dice_loss(logits, targets)
        per_sample = torch.where(
            operation_ids == self.DETECTION_ID,
            detection,
            segmentation,
        )
        return per_sample.mean()

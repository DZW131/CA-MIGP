from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


SEEDS = (17, 23, 42)
PRIMARY_FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
    "pannuke_ablation_constant_style",
    "pannuke_ablation_diagonal_style",
    "pannuke_ablation_no_spatial",
    "pannuke_ablation_no_modulation",
    "pannuke_multihead_unet",
    "pannuke_full_prompt_hed",
    "pannuke_ablation_no_style_hed",
)
ALTERNATE_ANNOTATION_FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
)
SUMMARY_EXPORTS = {
    "frozen_test": (
        "fold3_task_summary.json",
        "fold3_instance_summary.json",
        "test_instances.jsonl",
    ),
    "nuinsseg_ood": (
        "nuinsseg_task_summary.json",
        "nuinsseg_instance_summary.json",
        "ood_test_instances.jsonl",
    ),
    "cryonuseg_ann1_round1": (
        "cryonuseg_ann1_round1_task_summary.json",
        "cryonuseg_ann1_round1_instance_summary.json",
        "ood_test_instances.jsonl",
    ),
    "cryonuseg_ann1_round2": (
        "cryonuseg_ann1_round2_task_summary.json",
        "cryonuseg_ann1_round2_instance_summary.json",
        "ood_test_instances.jsonl",
    ),
    "cryonuseg_ann2": (
        "cryonuseg_ann2_task_summary.json",
        "cryonuseg_ann2_instance_summary.json",
        "ood_test_instances.jsonl",
    ),
}


@dataclass(frozen=True)
class ExportRecord:
    source: str
    destination: str
    bytes: int
    sha256: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export manuscript experiment evidence")
    parser.add_argument("--outputs", required=True, type=Path)
    parser.add_argument("--verified-root", required=True, type=Path)
    parser.add_argument("--per-image-root", required=True, type=Path)
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Require the complete planned experiment matrix.",
    )
    return parser.parse_args()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def export_file(
    source: Path,
    destination: Path,
    outputs: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    required: bool,
) -> bool:
    if not source.is_file():
        if required:
            raise ValueError(f"Missing required artifact: {source}")
        return False
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    records.append(
        ExportRecord(
            source=source.relative_to(outputs).as_posix(),
            destination=destination.relative_to(export_root).as_posix(),
            bytes=destination.stat().st_size,
            sha256=file_sha256(destination),
        )
    )
    return True


def export_evaluation(
    run_dir: Path,
    relative_dir: str,
    verified_run: Path,
    per_image_run: Path,
    outputs: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    prefix: str = "",
    required: bool,
) -> None:
    evaluation_dir = run_dir / relative_dir
    task_name, instance_name, instance_jsonl = SUMMARY_EXPORTS[relative_dir.rsplit("/", 1)[-1]]
    export_file(
        evaluation_dir / "task_summary.json",
        verified_run / f"{prefix}{task_name}",
        outputs,
        export_root,
        records,
        required=required,
    )
    export_file(
        evaluation_dir / ("test_instance_summary.json" if instance_jsonl.startswith("test") else "ood_test_instance_summary.json"),
        verified_run / f"{prefix}{instance_name}",
        outputs,
        export_root,
        records,
        required=required,
    )
    export_file(
        evaluation_dir / "per_image_tasks.jsonl",
        per_image_run / relative_dir / "per_image_tasks.jsonl",
        outputs,
        export_root,
        records,
        required=required,
    )
    export_file(
        evaluation_dir / instance_jsonl,
        per_image_run / relative_dir / instance_jsonl,
        outputs,
        export_root,
        records,
        required=required,
    )


def export_pathm_runs(
    outputs: Path,
    verified_root: Path,
    per_image_root: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    strict: bool,
) -> int:
    exported_runs = 0
    for family in PRIMARY_FAMILIES:
        for seed in SEEDS:
            run_name = f"{family}_seed{seed}"
            run_dir = outputs / run_name
            if not run_dir.is_dir():
                if strict:
                    raise ValueError(f"Missing required run: {run_dir}")
                continue
            exported_runs += 1
            verified_run = verified_root / run_name
            per_image_run = per_image_root / run_name
            for source_name, destination_name in (
                ("summary.json", "train_summary.json"),
                ("thresholds/detection.json", "val_detection_threshold.json"),
                ("thresholds/segmentation.json", "val_segmentation_threshold.json"),
            ):
                export_file(
                    run_dir / source_name,
                    verified_run / destination_name,
                    outputs,
                    export_root,
                    records,
                    required=strict,
                )
            for evaluation in ("frozen_test", "nuinsseg_ood", "cryonuseg_ann1_round1"):
                export_evaluation(
                    run_dir,
                    evaluation,
                    verified_run,
                    per_image_run,
                    outputs,
                    export_root,
                    records,
                    required=strict,
                )
            if family in ALTERNATE_ANNOTATION_FAMILIES:
                for annotation in ("cryonuseg_ann1_round2", "cryonuseg_ann2"):
                    export_evaluation(
                        run_dir,
                        annotation,
                        verified_run,
                        per_image_run,
                        outputs,
                        export_root,
                        records,
                        required=strict,
                    )
            if family == "pannuke_full_prompt":
                for evaluation in (
                    "frozen_test",
                    "nuinsseg_ood",
                    "cryonuseg_ann1_round1",
                ):
                    export_evaluation(
                        run_dir,
                        f"style_mismatch/{evaluation}",
                        verified_run,
                        per_image_run,
                        outputs,
                        export_root,
                        records,
                        prefix="style_mismatch_",
                        required=strict,
                    )
            for bootstrap in sorted(run_dir.glob("*bootstrap*.json")):
                export_file(
                    bootstrap,
                    verified_run / bootstrap.name,
                    outputs,
                    export_root,
                    records,
                    required=True,
                )
    return exported_runs


def export_cellvit(
    outputs: Path,
    verified_root: Path,
    per_image_root: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    strict: bool,
) -> bool:
    source_root = outputs / "cellvit256_fold1_baseline"
    if not source_root.is_dir():
        if strict:
            raise ValueError(f"Missing CellViT run: {source_root}")
        return False
    verified_run = verified_root / source_root.name
    per_image_run = per_image_root / source_root.name
    for name in ("state.json", "smoke.json", "efficiency.json", "environment.json"):
        export_file(
            source_root / name,
            verified_run / name,
            outputs,
            export_root,
            records,
            required=strict,
        )
    for label, instance_name in (
        ("pannuke_fold3", "test_instances.jsonl"),
        ("nuinsseg_ood", "ood_test_instances.jsonl"),
        ("cryonuseg_ann1_round1", "ood_test_instances.jsonl"),
        ("cryonuseg_ann1_round2", "ood_test_instances.jsonl"),
        ("cryonuseg_ann2", "ood_test_instances.jsonl"),
    ):
        for name in ("task_summary.json", "instance_summary.json", "metadata.json"):
            export_file(
                source_root / label / name,
                verified_run / label / name,
                outputs,
                export_root,
                records,
                required=strict,
            )
        for name in ("per_image_tasks.jsonl", instance_name):
            export_file(
                source_root / label / name,
                per_image_run / label / name,
                outputs,
                export_root,
                records,
                required=strict,
            )
    for bootstrap in sorted(source_root.glob("*bootstrap*.json")):
        export_file(
            bootstrap,
            verified_run / bootstrap.name,
            outputs,
            export_root,
            records,
            required=True,
        )
    return True


def export_annotation_agreement(
    outputs: Path,
    verified_root: Path,
    per_image_root: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    strict: bool,
) -> int:
    comparisons = ("ann1_round2_vs_round1", "ann2_vs_ann1_round1")
    exported = 0
    for comparison in comparisons:
        source = outputs / "cryonuseg_annotation_agreement" / comparison
        if not source.is_dir():
            if strict:
                raise ValueError(f"Missing annotation agreement: {source}")
            continue
        for name in ("summary.json", "bootstrap.json"):
            export_file(
                source / name,
                verified_root / "cryonuseg_annotation_agreement" / comparison / name,
                outputs,
                export_root,
                records,
                required=strict,
            )
        for name in ("per_image_tasks.jsonl", "ood_test_instances.jsonl"):
            export_file(
                source / name,
                per_image_root / "cryonuseg_annotation_agreement" / comparison / name,
                outputs,
                export_root,
                records,
                required=strict,
            )
        exported += 1
    return exported


def export_stain_robustness(
    outputs: Path,
    verified_root: Path,
    per_image_root: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    strict: bool,
) -> int:
    source_root = outputs / "stain_robustness"
    profiles = tuple(
        f"h{hematoxylin}_e{eosin}"
        for hematoxylin in ("0.7", "1.0", "1.3")
        for eosin in ("0.7", "1.0", "1.3")
    )
    exported = 0
    for model in ("full_prompt", "no_style"):
        for profile in profiles:
            source = source_root / model / profile
            if not source.is_dir():
                if strict:
                    raise ValueError(f"Missing stain-robustness profile: {source}")
                continue
            for name in ("task_summary.json", "test_instance_summary.json"):
                export_file(
                    source / name,
                    verified_root / "stain_robustness_seed17" / model / profile / name,
                    outputs,
                    export_root,
                    records,
                    required=strict,
                )
            for name in ("per_image_tasks.jsonl", "test_instances.jsonl"):
                export_file(
                    source / name,
                    per_image_root / "stain_robustness" / model / profile / name,
                    outputs,
                    export_root,
                    records,
                    required=strict,
                )
            exported += 1
    return exported


def export_efficiency(
    outputs: Path,
    verified_root: Path,
    export_root: Path,
    records: list[ExportRecord],
    *,
    strict: bool,
) -> int:
    source_root = outputs / "efficiency"
    exported = 0
    for name in (
        "full_prompt_seed17.json",
        "no_style_seed17.json",
        "multihead_seed17.json",
        "specialist_pair_seed17.json",
    ):
        if export_file(
            source_root / name,
            verified_root / "efficiency_seed17" / name,
            outputs,
            export_root,
            records,
            required=strict,
        ):
            exported += 1
    return exported


def main() -> None:
    args = parse_args()
    outputs = args.outputs.resolve()
    verified_root = args.verified_root.resolve()
    per_image_root = args.per_image_root.resolve()
    if verified_root.parent != per_image_root.parent:
        raise ValueError("Verified and per-image roots must share one parent directory")
    export_root = verified_root.parent
    records: list[ExportRecord] = []
    pathm_runs = export_pathm_runs(
        outputs,
        verified_root,
        per_image_root,
        export_root,
        records,
        strict=args.strict,
    )
    cellvit = export_cellvit(
        outputs,
        verified_root,
        per_image_root,
        export_root,
        records,
        strict=args.strict,
    )
    annotation_agreement = export_annotation_agreement(
        outputs,
        verified_root,
        per_image_root,
        export_root,
        records,
        strict=args.strict,
    )
    stain_profiles = export_stain_robustness(
        outputs,
        verified_root,
        per_image_root,
        export_root,
        records,
        strict=args.strict,
    )
    efficiency_files = export_efficiency(
        outputs,
        verified_root,
        export_root,
        records,
        strict=args.strict,
    )
    manifest = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_outputs": str(outputs),
        "pathm_runs": pathm_runs,
        "cellvit_exported": cellvit,
        "annotation_agreement_comparisons": annotation_agreement,
        "stain_profiles": stain_profiles,
        "efficiency_files": efficiency_files,
        "files": [record.__dict__ for record in records],
    }
    manifest_path = verified_root / "artifact_export_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "cellvit_exported": cellvit,
                "annotation_agreement_comparisons": annotation_agreement,
                "stain_profiles": stain_profiles,
                "efficiency_files": efficiency_files,
                "files": len(records),
                "manifest": str(manifest_path),
                "pathm_runs": pathm_runs,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

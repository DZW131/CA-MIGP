from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from statistics import mean, stdev


SEEDS = (17, 23, 42)
BASE_FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
    "pannuke_ablation_no_spatial",
    "pannuke_ablation_no_modulation",
    "pannuke_multihead_unet",
)
OPTIONAL_FAMILIES = (
    "pannuke_ablation_constant_style",
    "pannuke_ablation_diagonal_style",
    "pannuke_full_prompt_hed",
    "pannuke_ablation_no_style_hed",
)
SPLIT_FILES = {
    "pannuke_fold3": ("fold3_task_summary.json", "fold3_instance_summary.json"),
    "nuinsseg_ood": ("nuinsseg_task_summary.json", "nuinsseg_instance_summary.json"),
    "cryonuseg_ood": (
        "cryonuseg_ann1_round1_task_summary.json",
        "cryonuseg_ann1_round1_instance_summary.json",
    ),
}
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)
COMPARISONS = (
    ("full_minus_no_style", "pannuke_full_prompt", "pannuke_ablation_no_style"),
    ("no_spatial_minus_full", "pannuke_ablation_no_spatial", "pannuke_full_prompt"),
    (
        "no_spatial_minus_no_modulation",
        "pannuke_ablation_no_spatial",
        "pannuke_ablation_no_modulation",
    ),
    ("full_minus_multihead", "pannuke_full_prompt", "pannuke_multihead_unet"),
    (
        "full_minus_constant_style",
        "pannuke_full_prompt",
        "pannuke_ablation_constant_style",
    ),
    (
        "full_minus_diagonal_style",
        "pannuke_full_prompt",
        "pannuke_ablation_diagonal_style",
    ),
    (
        "full_hed_minus_no_style_hed",
        "pannuke_full_prompt_hed",
        "pannuke_ablation_no_style_hed",
    ),
    (
        "full_hed_minus_full",
        "pannuke_full_prompt_hed",
        "pannuke_full_prompt",
    ),
    (
        "no_style_hed_minus_no_style",
        "pannuke_ablation_no_style_hed",
        "pannuke_ablation_no_style",
    ),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize multi-seed and stain experiments")
    parser.add_argument("--verified-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def available_families(verified_root: Path) -> tuple[str, ...]:
    families = list(BASE_FAMILIES)
    for family in OPTIONAL_FAMILIES:
        exists = [
            (verified_root / f"{family}_seed{seed}" / "train_summary.json").is_file()
            for seed in SEEDS
        ]
        if any(exists) and not all(exists):
            raise ValueError(f"Incomplete optional family: {family}")
        if all(exists):
            families.append(family)
    return tuple(families)


def metric_values(
    verified_root: Path, families: tuple[str, ...]
) -> dict[tuple[str, int, str, str], float]:
    values: dict[tuple[str, int, str, str], float] = {}
    for family in families:
        for seed in SEEDS:
            run_dir = verified_root / f"{family}_seed{seed}"
            for split, (task_name, instance_name) in SPLIT_FILES.items():
                merged = {**read_json(run_dir / task_name), **read_json(run_dir / instance_name)}
                for metric in METRICS:
                    values[(family, seed, split, metric)] = float(merged[metric])
    return values


def summarize_multiseed(
    values: dict[tuple[str, int, str, str], float], families: tuple[str, ...]
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    summaries: list[dict[str, object]] = []
    for family in families:
        for split in SPLIT_FILES:
            for metric in METRICS:
                per_seed = {
                    str(seed): values[(family, seed, split, metric)] for seed in SEEDS
                }
                metric_values = list(per_seed.values())
                summaries.append(
                    {
                        "family": family,
                        "split": split,
                        "metric": metric,
                        "n": len(metric_values),
                        "mean": mean(metric_values),
                        "sample_sd": stdev(metric_values),
                        "minimum": min(metric_values),
                        "maximum": max(metric_values),
                        "per_seed": per_seed,
                    }
                )

    comparisons: list[dict[str, object]] = []
    for name, candidate, reference in COMPARISONS:
        if candidate not in families or reference not in families:
            continue
        for split in SPLIT_FILES:
            for metric in METRICS:
                per_seed = {
                    str(seed): values[(candidate, seed, split, metric)]
                    - values[(reference, seed, split, metric)]
                    for seed in SEEDS
                }
                differences = list(per_seed.values())
                comparisons.append(
                    {
                        "comparison": name,
                        "candidate": candidate,
                        "reference": reference,
                        "split": split,
                        "metric": metric,
                        "n": len(differences),
                        "mean_difference": mean(differences),
                        "sample_sd": stdev(differences),
                        "positive_seeds": sum(value > 0 for value in differences),
                        "per_seed": per_seed,
                    }
                )
    factorial_families = {
        "pannuke_full_prompt_hed",
        "pannuke_ablation_no_style_hed",
        "pannuke_full_prompt",
        "pannuke_ablation_no_style",
    }
    if factorial_families.issubset(families):
        for split in SPLIT_FILES:
            for metric in METRICS:
                per_seed = {
                    str(seed): (
                        values[("pannuke_full_prompt_hed", seed, split, metric)]
                        - values[("pannuke_ablation_no_style_hed", seed, split, metric)]
                        - values[("pannuke_full_prompt", seed, split, metric)]
                        + values[("pannuke_ablation_no_style", seed, split, metric)]
                    )
                    for seed in SEEDS
                }
                differences = list(per_seed.values())
                comparisons.append(
                    {
                        "comparison": "style_by_hed_interaction",
                        "candidate": "full_hed_minus_no_style_hed",
                        "reference": "full_minus_no_style",
                        "split": split,
                        "metric": metric,
                        "n": len(differences),
                        "mean_difference": mean(differences),
                        "sample_sd": stdev(differences),
                        "positive_seeds": sum(value > 0 for value in differences),
                        "per_seed": per_seed,
                    }
                )
    return summaries, comparisons


def summarize_stain(verified_root: Path) -> list[dict[str, object]]:
    stain_root = verified_root / "stain_robustness_seed17"
    records: dict[tuple[str, str], dict[str, object]] = {}
    profile_pattern = re.compile(r"h(?P<h>[0-9.]+)_e(?P<e>[0-9.]+)")
    for model_dir in sorted(path for path in stain_root.iterdir() if path.is_dir()):
        for profile_dir in sorted(path for path in model_dir.iterdir() if path.is_dir()):
            match = profile_pattern.fullmatch(profile_dir.name)
            if match is None:
                raise ValueError(f"Invalid stain profile directory: {profile_dir}")
            merged = {
                **read_json(profile_dir / "task_summary.json"),
                **read_json(profile_dir / "test_instance_summary.json"),
            }
            record = {
                "model": model_dir.name,
                "profile": profile_dir.name,
                "hematoxylin_scale": float(match.group("h")),
                "eosin_scale": float(match.group("e")),
                **{metric: float(merged[metric]) for metric in METRICS},
            }
            records[(model_dir.name, profile_dir.name)] = record

    output: list[dict[str, object]] = []
    for key in sorted(records):
        output.append(records[key])
    for profile in sorted({profile for _, profile in records}):
        full = records[("full_prompt", profile)]
        no_style = records[("no_style", profile)]
        output.append(
            {
                "model": "full_minus_no_style",
                "profile": profile,
                "hematoxylin_scale": full["hematoxylin_scale"],
                "eosin_scale": full["eosin_scale"],
                **{
                    metric: float(full[metric]) - float(no_style[metric])
                    for metric in METRICS
                },
            }
        )
    return output


def write_records(path: Path, records: list[dict[str, object]]) -> None:
    path.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, records: list[dict[str, object]]) -> None:
    flattened: list[dict[str, object]] = []
    for record in records:
        row = {key: value for key, value in record.items() if key != "per_seed"}
        per_seed = record.get("per_seed")
        if isinstance(per_seed, dict):
            row.update({f"seed_{seed}": value for seed, value in per_seed.items()})
        flattened.append(row)
    fieldnames = list(dict.fromkeys(key for record in flattened for key in record))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(flattened)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    families = available_families(args.verified_root)
    values = metric_values(args.verified_root, families)
    summaries, comparisons = summarize_multiseed(values, families)
    stain = summarize_stain(args.verified_root)
    for name, records in (
        ("multiseed_summary", summaries),
        ("multiseed_comparisons", comparisons),
        ("stain_robustness", stain),
    ):
        write_records(args.output_dir / f"{name}.json", records)
        write_csv(args.output_dir / f"{name}.csv", records)
    print(
        json.dumps(
            {
                "multiseed_rows": len(summaries),
                "comparison_rows": len(comparisons),
                "families": families,
                "stain_rows": len(stain),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

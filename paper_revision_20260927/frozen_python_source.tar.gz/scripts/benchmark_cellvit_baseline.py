from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
import yaml

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "scripts"))

from evaluate_cellvit_baseline import load_cellvit  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Benchmark the pinned CellViT baseline")
    parser.add_argument("--external-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--height", type=int, default=256)
    parser.add_argument("--width", type=int, default=256)
    parser.add_argument("--warmup", type=int, default=30)
    parser.add_argument("--repeats", type=int, default=100)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.batch_size <= 0 or args.repeats <= 0 or args.warmup < 0:
        raise ValueError("batch size and repeats must be positive; warmup must be non-negative")
    config = yaml.safe_load(args.config.resolve().read_text(encoding="utf-8"))
    device = torch.device(args.device)
    model, checkpoint = load_cellvit(
        args.external_root.resolve(), config, args.checkpoint.resolve(), device
    )
    image = torch.randn(
        args.batch_size,
        3,
        args.height,
        args.width,
        dtype=torch.float32,
        device=device,
    )

    def forward() -> None:
        model(image)

    use_amp = device.type == "cuda"
    with torch.inference_mode(), torch.autocast(
        device_type=device.type,
        dtype=torch.float16,
        enabled=use_amp,
    ):
        for _ in range(args.warmup):
            forward()
        if device.type == "cuda":
            torch.cuda.synchronize(device)
            torch.cuda.reset_peak_memory_stats(device)
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(args.repeats):
                forward()
            end.record()
            torch.cuda.synchronize(device)
            latency_ms = start.elapsed_time(end) / args.repeats
            peak_memory_mib = torch.cuda.max_memory_allocated(device) / 1024**2
        else:
            import time

            started = time.perf_counter()
            for _ in range(args.repeats):
                forward()
            latency_ms = (time.perf_counter() - started) * 1000.0 / args.repeats
            peak_memory_mib = None

        flop_count = None
        try:
            from torch.utils.flop_counter import FlopCounterMode

            with FlopCounterMode(display=False) as counter:
                forward()
            flop_count = int(counter.get_total_flops())
        except (ImportError, RuntimeError, TypeError):
            pass

    parameters = sum(parameter.numel() for parameter in model.parameters())
    output = {
        "method": "CellViT-256 Shared",
        "checkpoint_architecture": str(checkpoint["arch"]),
        "checkpoint_epoch_index": int(checkpoint["epoch"]),
        "device": str(device),
        "device_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "amp_dtype": "float16" if use_amp else "float32",
        "batch_size": args.batch_size,
        "height": args.height,
        "width": args.width,
        "warmup": args.warmup,
        "repeats": args.repeats,
        "mode": "joint_instance_segmentation",
        "parameters": parameters,
        "latency_ms_per_batch": latency_ms,
        "latency_ms_per_image": latency_ms / args.batch_size,
        "peak_gpu_memory_mib": peak_memory_mib,
        "flops_per_batch": flop_count,
        "flops_per_image": flop_count / args.batch_size if flop_count is not None else None,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

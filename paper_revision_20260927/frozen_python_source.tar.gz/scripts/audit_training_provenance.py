from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

import yaml

from train import PROVENANCE_SOURCE_PATHS


SEEDS = (17, 23, 42)
FAMILIES = (
    "pannuke_ablation_constant_style",
    "pannuke_ablation_diagonal_style",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit source provenance for mechanism-control training runs"
    )
    parser.add_argument("--repository", type=Path, default=Path.cwd())
    parser.add_argument("--outputs", required=True, type=Path)
    parser.add_argument("--reference-commit", default="9bce725")
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def git(repository: Path, *arguments: str) -> str:
    return subprocess.check_output(
        ["git", *arguments], cwd=repository, text=True
    ).strip()


def git_bytes(repository: Path, commit: str, relative_path: str) -> bytes:
    return subprocess.check_output(
        ["git", "show", f"{commit}:{relative_path}"], cwd=repository
    )


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def commit_file_hash(repository: Path, commit: str, relative_path: str) -> str:
    return sha256(git_bytes(repository, commit, relative_path))


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def normalized_yaml(value: bytes | str) -> object:
    text = value.decode("utf-8") if isinstance(value, bytes) else value
    return yaml.safe_load(text)


def audit_launch(
    repository: Path,
    launch: dict[str, object],
    config_relative_path: str,
) -> dict[str, object]:
    commit = launch.get("git_commit")
    require(isinstance(commit, str) and len(commit) == 40, "Invalid launch commit")
    require(launch.get("git_dirty") is False, f"Dirty launch at {commit}")
    expected_config_hash = commit_file_hash(repository, commit, config_relative_path)
    require(
        launch.get("config_sha256") == expected_config_hash,
        f"Launch configuration hash mismatch at {commit}",
    )
    source_hashes = launch.get("source_sha256")
    require(isinstance(source_hashes, dict), f"Missing source hashes at {commit}")
    for relative_path in PROVENANCE_SOURCE_PATHS:
        require(
            source_hashes.get(relative_path)
            == commit_file_hash(repository, commit, relative_path),
            f"Source hash mismatch at {commit}: {relative_path}",
        )
    return {"commit": commit, "status": "launch_hashes_verified"}


def main() -> None:
    args = parse_args()
    repository = args.repository.resolve()
    outputs = args.outputs.resolve()
    reference_commit = git(repository, "rev-parse", args.reference_commit)
    current_commit = git(repository, "rev-parse", "HEAD")
    common_hashes = {
        relative_path: {
            "reference": commit_file_hash(repository, reference_commit, relative_path),
            "current": commit_file_hash(repository, current_commit, relative_path),
        }
        for relative_path in PROVENANCE_SOURCE_PATHS
    }
    runs: list[dict[str, object]] = []
    for family in FAMILIES:
        for seed in SEEDS:
            run_name = f"{family}_seed{seed}"
            summary = read_json(outputs / run_name / "summary.json")
            reported_commit = summary.get("git_commit")
            require(
                isinstance(reported_commit, str) and len(reported_commit) == 40,
                f"Invalid reported commit: {run_name}",
            )
            require(summary.get("git_dirty") is False, f"Dirty run: {run_name}")
            config_relative_path = f"configs/{run_name}.yaml"
            stored_config = (outputs / run_name / "config.yaml").read_text(
                encoding="utf-8"
            )
            require(
                normalized_yaml(stored_config)
                == normalized_yaml(
                    git_bytes(repository, reported_commit, config_relative_path)
                ),
                f"Stored configuration mismatch: {run_name}",
            )
            stable_hashes = {
                relative_path: commit_file_hash(
                    repository, reported_commit, relative_path
                )
                == common_hashes[relative_path]["reference"]
                for relative_path in PROVENANCE_SOURCE_PATHS
            }
            launches = summary.get("source_provenance")
            if isinstance(launches, list) and launches:
                launch_audits = [
                    audit_launch(repository, launch, config_relative_path)
                    for launch in launches
                    if isinstance(launch, dict)
                ]
                require(
                    len(launch_audits) == len(launches),
                    f"Malformed launch provenance: {run_name}",
                )
                status = "launch_hashes_verified"
            else:
                require(
                    all(stable_hashes.values()),
                    f"Legacy training source drift: {run_name}",
                )
                launch_audits = []
                status = "source_range_stable"
            runs.append(
                {
                    "run_name": run_name,
                    "seed": seed,
                    "reported_commit": reported_commit,
                    "status": status,
                    "launches": launch_audits,
                    "source_files_unchanged_from_reference": all(stable_hashes.values()),
                    "stored_config_matches_reported_commit": True,
                }
            )

    result = {
        "schema_version": 1,
        "reference_commit": reference_commit,
        "current_commit": current_commit,
        "interpretation": (
            "Runs without launch-time hashes are accepted only because every loaded "
            "training source file is byte-identical from the control implementation "
            "commit through the commit reported at run completion."
        ),
        "source_files": common_hashes,
        "runs": runs,
        "status": "passed",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"runs": len(runs), "status": "passed"}, sort_keys=True))


if __name__ == "__main__":
    main()

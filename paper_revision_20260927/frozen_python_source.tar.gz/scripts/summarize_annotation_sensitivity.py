from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from statistics import mean, stdev

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "scripts"))

from bootstrap_ci import load_jsonl, point_metrics  # noqa: E402


SEEDS = (17, 23, 42)
MODELS = {
    "full_prompt": "pannuke_full_prompt",
    "no_style": "pannuke_ablation_no_style",
}
ANNOTATIONS = ("ann1_round1", "ann1_round2", "ann2")
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize CryoNuSeg annotation sensitivity")
    parser.add_argument("--per-image-root", required=True, type=Path)
    parser.add_argument("--agreement-root", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fieldnames = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    rows: list[dict[str, object]] = []
    for model, family in MODELS.items():
        for seed in SEEDS:
            for annotation in ANNOTATIONS:
                evaluation_dir = (
                    args.per_image_root
                    / f"{family}_seed{seed}"
                    / f"cryonuseg_{annotation}"
                )
                rows.append(
                    {
                        "model": model,
                        "seed": seed,
                        "annotation": annotation,
                        **point_metrics(
                            load_jsonl(evaluation_dir / "per_image_tasks.jsonl"),
                            load_jsonl(evaluation_dir / "ood_test_instances.jsonl"),
                        ),
                    }
                )

    indexed = {
        (str(row["model"]), int(row["seed"]), str(row["annotation"])): row
        for row in rows
    }
    summaries: list[dict[str, object]] = []
    for model in MODELS:
        for annotation in ANNOTATIONS:
            for metric in METRICS:
                values = [
                    float(indexed[(model, seed, annotation)][metric]) for seed in SEEDS
                ]
                summaries.append(
                    {
                        "analysis": "model_score",
                        "model": model,
                        "annotation": annotation,
                        "metric": metric,
                        "mean": mean(values),
                        "sample_sd": stdev(values),
                        "positive_seeds": None,
                    }
                )

    differences: list[dict[str, object]] = []
    for annotation in ANNOTATIONS:
        for seed in SEEDS:
            full = indexed[("full_prompt", seed, annotation)]
            no_style = indexed[("no_style", seed, annotation)]
            differences.append(
                {
                    "analysis": "full_minus_no_style",
                    "model": "full_prompt_minus_no_style",
                    "seed": seed,
                    "annotation": annotation,
                    **{
                        metric: float(full[metric]) - float(no_style[metric])
                        for metric in METRICS
                    },
                }
            )
    for annotation in ANNOTATIONS:
        for metric in METRICS:
            values = [
                float(row[metric])
                for row in differences
                if row["annotation"] == annotation
            ]
            summaries.append(
                {
                    "analysis": "full_minus_no_style",
                    "model": "full_prompt_minus_no_style",
                    "annotation": annotation,
                    "metric": metric,
                    "mean": mean(values),
                    "sample_sd": stdev(values),
                    "positive_seeds": sum(value > 0 for value in values),
                }
            )

    for model in MODELS:
        for annotation in ("ann1_round2", "ann2"):
            for seed in SEEDS:
                candidate = indexed[(model, seed, annotation)]
                reference = indexed[(model, seed, "ann1_round1")]
                differences.append(
                    {
                        "analysis": "reference_sensitivity",
                        "model": model,
                        "seed": seed,
                        "annotation": f"{annotation}_minus_ann1_round1",
                        **{
                            metric: float(candidate[metric]) - float(reference[metric])
                            for metric in METRICS
                        },
                    }
                )
            annotation_label = f"{annotation}_minus_ann1_round1"
            for metric in METRICS:
                values = [
                    float(row[metric])
                    for row in differences
                    if row["analysis"] == "reference_sensitivity"
                    and row["model"] == model
                    and row["annotation"] == annotation_label
                ]
                summaries.append(
                    {
                        "analysis": "reference_sensitivity",
                        "model": model,
                        "annotation": annotation_label,
                        "metric": metric,
                        "mean": mean(values),
                        "sample_sd": stdev(values),
                        "positive_seeds": sum(value > 0 for value in values),
                    }
                )

    human_agreement: list[dict[str, object]] = []
    if args.agreement_root is not None:
        for comparison in ("ann1_round2_vs_round1", "ann2_vs_ann1_round1"):
            summary = json.loads(
                (args.agreement_root / comparison / "summary.json").read_text(
                    encoding="utf-8"
                )
            )
            human_agreement.append({"comparison": comparison, **summary})

    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, records in (
        ("annotation_model_scores", rows),
        ("annotation_differences", differences),
        ("annotation_summary", summaries),
        ("human_agreement", human_agreement),
    ):
        (args.output_dir / f"{name}.json").write_text(
            json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        write_csv(args.output_dir / f"{name}.csv", records)
    print(
        json.dumps(
            {
                "human_agreement_rows": len(human_agreement),
                "model_rows": len(rows),
                "summary_rows": len(summaries),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

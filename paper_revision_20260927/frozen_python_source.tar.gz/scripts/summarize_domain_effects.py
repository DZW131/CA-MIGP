from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from statistics import mean, median

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "scripts"))

from bootstrap_ci import grouped_records, load_jsonl, point_metrics  # noqa: E402


SEEDS = (17, 23, 42)
MODELS = {
    "full_prompt": "pannuke_full_prompt",
    "no_style": "pannuke_ablation_no_style",
    "constant_style": "pannuke_ablation_constant_style",
    "diagonal_style": "pannuke_ablation_diagonal_style",
    "no_spatial": "pannuke_ablation_no_spatial",
    "no_modulation": "pannuke_ablation_no_modulation",
    "multihead": "pannuke_multihead_unet",
    "full_prompt_hed": "pannuke_full_prompt_hed",
    "no_style_hed": "pannuke_ablation_no_style_hed",
}
COMPARISONS = (
    ("full_prompt", "no_style"),
    ("full_prompt", "constant_style"),
    ("full_prompt", "diagonal_style"),
    ("no_spatial", "full_prompt"),
    ("full_prompt", "no_modulation"),
    ("full_prompt", "multihead"),
    ("full_prompt_hed", "no_style_hed"),
    ("full_prompt_hed", "full_prompt"),
    ("no_style_hed", "no_style"),
)
DATASETS = {
    "nuinsseg_ood": ("nuinsseg_ood", "sample_id"),
    "cryonuseg_ood": ("cryonuseg_ann1_round1", "domain"),
}
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize external-test effects by domain")
    parser.add_argument("--per-image-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def domain_metrics(
    run_dir: Path, relative_dir: str, group_key: str
) -> list[dict[str, object]]:
    evaluation_dir = run_dir / relative_dir
    task_groups = grouped_records(
        load_jsonl(evaluation_dir / "per_image_tasks.jsonl"), group_key
    )
    instance_groups = grouped_records(
        load_jsonl(evaluation_dir / "ood_test_instances.jsonl"), group_key
    )
    domains = sorted(set(task_groups) & set(instance_groups))
    if set(task_groups) != set(instance_groups):
        raise ValueError(f"Task/instance domain mismatch: {run_dir}")
    return [
        {
            "domain": domain,
            "images": len(instance_groups[domain]),
            **point_metrics(task_groups[domain], instance_groups[domain]),
        }
        for domain in domains
    ]


def comparison_summary(
    rows: list[dict[str, object]], dataset: str, candidate: str, reference: str
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    indexed = {
        (
            str(row["dataset"]),
            str(row["model"]),
            int(row["seed"]),
            str(row["domain"]),
        ): row
        for row in rows
    }
    domains = sorted(
        {
            str(row["domain"])
            for row in rows
            if row["dataset"] == dataset
            and row["model"] == candidate
            and (dataset, reference, int(row["seed"]), str(row["domain"])) in indexed
        }
    )
    differences: list[dict[str, object]] = []
    for seed in SEEDS:
        for domain in domains:
            candidate_row = indexed[(dataset, candidate, seed, domain)]
            reference_row = indexed[(dataset, reference, seed, domain)]
            differences.append(
                {
                    "comparison": f"{candidate}_minus_{reference}",
                    "dataset": dataset,
                    "seed": seed,
                    "domain": domain,
                    "images": candidate_row["images"],
                    **{
                        metric: float(candidate_row[metric]) - float(reference_row[metric])
                        for metric in METRICS
                    },
                }
            )

    summaries: list[dict[str, object]] = []
    for metric in METRICS:
        domain_means = {
            domain: mean(
                float(row[metric]) for row in differences if row["domain"] == domain
            )
            for domain in domains
        }
        values = list(domain_means.values())
        summaries.append(
            {
                "comparison": f"{candidate}_minus_{reference}",
                "dataset": dataset,
                "metric": metric,
                "domains": len(values),
                "positive_domains": sum(value > 0 for value in values),
                "mean_unweighted_domain_difference": mean(values),
                "median_domain_difference": median(values),
                "minimum_domain_difference": min(values),
                "maximum_domain_difference": max(values),
                "domain_mean_differences": domain_means,
            }
        )
    return differences, summaries


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fieldnames = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    rows: list[dict[str, object]] = []
    available_models: dict[str, list[str]] = {dataset: [] for dataset in DATASETS}
    for model, family in MODELS.items():
        run_dirs = [args.per_image_root / f"{family}_seed{seed}" for seed in SEEDS]
        if not all(run_dir.is_dir() for run_dir in run_dirs):
            continue
        for dataset, (relative_dir, group_key) in DATASETS.items():
            if not all((run_dir / relative_dir).is_dir() for run_dir in run_dirs):
                continue
            available_models[dataset].append(model)
            for seed, run_dir in zip(SEEDS, run_dirs, strict=True):
                rows.extend(
                    {"dataset": dataset, "model": model, "seed": seed, **row}
                    for row in domain_metrics(run_dir, relative_dir, group_key)
                )

    all_differences: list[dict[str, object]] = []
    all_summaries: list[dict[str, object]] = []
    for dataset, models in available_models.items():
        for candidate, reference in COMPARISONS:
            if candidate not in models or reference not in models:
                continue
            differences, summaries = comparison_summary(
                rows, dataset, candidate, reference
            )
            all_differences.extend(differences)
            all_summaries.extend(summaries)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, records in (
        ("domain_metrics", rows),
        ("domain_differences", all_differences),
        ("domain_effect_summary", all_summaries),
    ):
        (args.output_dir / f"{name}.json").write_text(
            json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        write_csv(args.output_dir / f"{name}.csv", records)
    print(
        json.dumps(
            {
                "comparisons": len(all_summaries) // len(METRICS),
                "domains": {
                    dataset: len(
                        {row["domain"] for row in rows if row["dataset"] == dataset}
                    )
                    for dataset in DATASETS
                },
                "models": available_models,
                "rows": len(rows),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

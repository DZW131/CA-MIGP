from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path

from bootstrap_ci import load_jsonl, propagate_group_key
from summarize_somigp import aggregate, collect_scores, comparisons


MANIFEST_SHA256 = "2049e5d760805b7ed4c2aaff8b8ee2a1297c0607188a085b5d1b200f3c954b5c"
EXPECTED_FAMILIES = {
    "pannuke_full_prompt": (17, 23, 42),
    "pannuke_somigp": (17, 23, 42),
    "pannuke_gap_control": (17, 23, 42),
    "pannuke_geometry_no_orth": (17, 23, 42),
    "pannuke_geometry_no_contact": (17, 23, 42),
    "pannuke_geometry_constant_direction": (17,),
    "pannuke_no_style_geometry": (17,),
    "pannuke_ablation_no_style": (17,),
}
DIAGNOSTIC_METRICS = (
    "mean_boundary_f1",
    "mean_count_absolute_error",
    "contact_instance_recall",
    "contact_pair_success_rate",
    "contact_pair_merge_rate",
)
BOUNDED_METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_dq",
    "global_sq",
    "global_pq",
    "mean_boundary_f1",
    "contact_instance_recall",
    "contact_pair_success_rate",
    "contact_pair_merge_rate",
)


@dataclass(frozen=True)
class EvaluationSpec:
    relative_dir: str
    instance_file: str
    task_records: int
    instance_records: int
    cluster_key: str
    clusters: int


PRIMARY_EVALUATIONS = {
    "pannuke_fold3": EvaluationSpec(
        "frozen_test", "test_instances.jsonl", 5444, 2722, "sample_id", 2722
    ),
    "nuinsseg": EvaluationSpec(
        "nuinsseg_ood", "ood_test_instances.jsonl", 1330, 665, "sample_id", 31
    ),
    "cryonuseg_ann1_round1": EvaluationSpec(
        "cryonuseg_ann1_round1",
        "ood_test_instances.jsonl",
        60,
        30,
        "domain",
        10,
    ),
}
SENSITIVITY_EVALUATIONS = {
    "cryonuseg_ann1_round2": EvaluationSpec(
        "cryonuseg_ann1_round2",
        "ood_test_instances.jsonl",
        60,
        30,
        "domain",
        10,
    ),
    "cryonuseg_ann2": EvaluationSpec(
        "cryonuseg_ann2", "ood_test_instances.jsonl", 60, 30, "domain", 10
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit final SO-MIGP evidence")
    parser.add_argument("--outputs-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    if not path.is_file():
        raise ValueError(f"Missing JSON artifact: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return payload


def finite_number(value: object, label: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"Non-finite value for {label}: {value}")
    return number


def audit_metric_summary(
    task_summary: dict[str, object],
    instance_summary: dict[str, object],
    label: str,
) -> None:
    merged = {**task_summary, **instance_summary}
    for metric in BOUNDED_METRICS:
        value = finite_number(merged[metric], f"{label}:{metric}")
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"Out-of-range metric {label}:{metric}={value}")
    count_error = finite_number(
        merged["mean_count_absolute_error"],
        f"{label}:mean_count_absolute_error",
    )
    if count_error < 0.0:
        raise ValueError(f"Negative count error for {label}")


def audit_evaluation(run_dir: Path, label: str, spec: EvaluationSpec) -> dict[str, object]:
    evaluation = run_dir / spec.relative_dir
    task_path = evaluation / "per_image_tasks.jsonl"
    instance_path = evaluation / spec.instance_file
    task_records = load_jsonl(task_path)
    instance_records = load_jsonl(instance_path)
    if len(task_records) != spec.task_records:
        raise ValueError(
            f"Unexpected task rows for {run_dir.name}:{label}: {len(task_records)}"
        )
    if len(instance_records) != spec.instance_records:
        raise ValueError(
            f"Unexpected instance rows for {run_dir.name}:{label}: "
            f"{len(instance_records)}"
        )
    operations = {
        operation: sum(record.get("operation") == operation for record in task_records)
        for operation in ("detection", "segmentation")
    }
    if any(count != spec.instance_records for count in operations.values()):
        raise ValueError(f"Task operation counts do not match images: {run_dir.name}:{label}")
    propagate_group_key(task_records, instance_records, spec.cluster_key)
    propagate_group_key(instance_records, task_records, spec.cluster_key)
    task_groups = {str(record[spec.cluster_key]) for record in task_records}
    instance_groups = {str(record[spec.cluster_key]) for record in instance_records}
    if task_groups != instance_groups or len(task_groups) != spec.clusters:
        raise ValueError(f"Unexpected bootstrap groups: {run_dir.name}:{label}")
    missing_diagnostics = [
        index
        for index, record in enumerate(instance_records)
        if "boundary_f1" not in record or "contact_pairs" not in record
    ]
    if missing_diagnostics:
        raise ValueError(
            f"Missing diagnostics in {len(missing_diagnostics)} rows: {run_dir.name}:{label}"
        )
    task_summary = read_json(evaluation / "task_summary.json")
    summary_name = (
        "test_instance_summary.json"
        if spec.instance_file.startswith("test")
        else "ood_test_instance_summary.json"
    )
    instance_summary = read_json(evaluation / summary_name)
    audit_metric_summary(task_summary, instance_summary, f"{run_dir.name}:{label}")
    return {
        "label": label,
        "images": len(instance_records),
        "task_records": len(task_records),
        "bootstrap_unit": spec.cluster_key,
        "bootstrap_groups": len(task_groups),
    }


def audit_run(
    outputs_root: Path,
    family: str,
    seed: int,
    *,
    sensitivity: bool,
) -> dict[str, object]:
    run_name = f"{family}_seed{seed}"
    run_dir = outputs_root / run_name
    summary = read_json(run_dir / "summary.json")
    if summary.get("status") != "completed":
        raise ValueError(f"Training is not complete: {run_name}")
    if summary.get("run_name") != run_name or int(summary["seed"]) != seed:
        raise ValueError(f"Training identity mismatch: {run_name}")
    if int(summary["epochs"]) != 50:
        raise ValueError(f"Unexpected training budget: {run_name}")
    if summary.get("manifest_sha256") != MANIFEST_SHA256:
        raise ValueError(f"Manifest hash mismatch: {run_name}")
    for task in ("detection", "segmentation"):
        threshold = read_json(run_dir / "thresholds" / f"{task}.json")
        value = finite_number(threshold["selected_threshold"], f"{run_name}:{task}")
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"Invalid threshold for {run_name}:{task}")
    evaluations = [
        audit_evaluation(run_dir, label, spec)
        for label, spec in PRIMARY_EVALUATIONS.items()
    ]
    if sensitivity:
        evaluations.extend(
            audit_evaluation(run_dir, label, spec)
            for label, spec in SENSITIVITY_EVALUATIONS.items()
        )
    return {
        "run_name": run_name,
        "seed": seed,
        "parameters": int(summary["parameters"]),
        "duration_seconds": finite_number(
            summary["duration_seconds"], f"{run_name}:duration_seconds"
        ),
        "peak_gpu_memory_mib": finite_number(
            summary["peak_gpu_memory_mib"], f"{run_name}:peak_gpu_memory_mib"
        ),
        "evaluations": evaluations,
    }


def audit_bootstraps(outputs_root: Path) -> dict[str, int]:
    per_seed = 0
    for seed in (17, 23, 42):
        run_dir = outputs_root / f"pannuke_somigp_seed{seed}"
        for split in PRIMARY_EVALUATIONS.values():
            for reference in ("full", "gap", "no_orth", "no_contact"):
                path = (
                    run_dir
                    / f"{split.relative_dir}_vs_{reference}_paired_bootstrap.json"
                )
                payload = read_json(path)
                if int(payload["replicates"]) != 10000:
                    raise ValueError(f"Unexpected bootstrap replicates: {path}")
                metrics = payload.get("metrics", {})
                if not isinstance(metrics, dict) or any(
                    metric not in metrics for metric in DIAGNOSTIC_METRICS
                ):
                    raise ValueError(f"Incomplete bootstrap metrics: {path}")
                per_seed += 1
    for reference in ("constant_direction", "no_style_geometry"):
        for split in ("frozen_test", "nuinsseg_ood"):
            path = (
                outputs_root
                / "pannuke_somigp_seed17"
                / f"{split}_vs_{reference}_paired_bootstrap.json"
            )
            read_json(path)
            per_seed += 1

    no_style_geometry = outputs_root / "pannuke_no_style_geometry_seed17"
    for spec in PRIMARY_EVALUATIONS.values():
        path = (
            no_style_geometry
            / f"{spec.relative_dir}_vs_no_style_paired_bootstrap.json"
        )
        payload = read_json(path)
        if int(payload["replicates"]) != 10000:
            raise ValueError(f"Unexpected bootstrap replicates: {path}")
        per_seed += 1

    hierarchical = 0
    root = outputs_root / "somigp_hierarchical_bootstrap"
    for spec in PRIMARY_EVALUATIONS.values():
        for reference in ("full", "gap", "no_orth", "no_contact"):
            path = root / f"{spec.relative_dir}_vs_{reference}.json"
            payload = read_json(path)
            if payload.get("bootstrap_unit") != f"seed_then_{spec.cluster_key}":
                raise ValueError(f"Unexpected hierarchical bootstrap unit: {path}")
            if int(payload["replicates"]) != 10000:
                raise ValueError(f"Unexpected hierarchical replicates: {path}")
            hierarchical += 1
    return {"within_seed_files": per_seed, "hierarchical_files": hierarchical}


def audit_efficiency(outputs_root: Path) -> dict[str, object]:
    root = outputs_root / "somigp_efficiency"
    full = read_json(root / "full_seed17.json")
    somigp = read_json(root / "somigp_seed17.json")
    for label, payload in (("full", full), ("somigp", somigp)):
        for key in (
            "parameters",
            "active_inference_parameters",
            "inactive_training_only_parameters",
            "flops_per_image",
            "latency_ms_per_image",
            "peak_gpu_memory_mib",
        ):
            finite_number(payload[key], f"efficiency:{label}:{key}")
    if int(full["active_inference_parameters"]) != int(
        somigp["active_inference_parameters"]
    ):
        raise ValueError("SO-MIGP and Full active inference parameter counts differ")
    full_flops = finite_number(full["flops_per_image"], "efficiency:full:flops")
    somigp_flops = finite_number(somigp["flops_per_image"], "efficiency:somigp:flops")
    if not math.isclose(full_flops, somigp_flops, rel_tol=0.0, abs_tol=0.0):
        raise ValueError("SO-MIGP and Full active inference FLOPs differ")
    if int(somigp["inactive_training_only_parameters"]) <= 0:
        raise ValueError("SO-MIGP training-only parameters were not identified")
    return {
        "full": full,
        "somigp": somigp,
        "active_parameter_delta": int(somigp["active_inference_parameters"])
        - int(full["active_inference_parameters"]),
        "active_flop_delta": somigp_flops - full_flops,
    }


def audit_stain_stress(outputs_root: Path) -> dict[str, object]:
    roots = {
        "full": outputs_root / "stain_robustness" / "full_prompt",
        "somigp": outputs_root / "somigp_stain_stress",
    }
    profiles: list[str] = []
    evaluations = 0
    for family, root in roots.items():
        for hematoxylin in (0.7, 1.0, 1.3):
            for eosin in (0.7, 1.0, 1.3):
                profile = f"h{hematoxylin}_e{eosin}"
                task = read_json(root / profile / "task_summary.json")
                instance = read_json(root / profile / "test_instance_summary.json")
                if family == "somigp":
                    audit_metric_summary(task, instance, f"stain:{family}:{profile}")
                else:
                    merged = {**task, **instance}
                    for metric in (
                        "detection_f1",
                        "segmentation_dice",
                        "segmentation_iou",
                        "mean_aji_plus",
                        "mean_pq",
                        "global_pq",
                    ):
                        value = finite_number(
                            merged[metric], f"stain:{family}:{profile}:{metric}"
                        )
                        if not 0.0 <= value <= 1.0:
                            raise ValueError(
                                f"Out-of-range stain metric {family}:{profile}:{metric}"
                            )
                records = load_jsonl(root / profile / "test_instances.jsonl")
                if len(records) != 2722:
                    raise ValueError(
                        f"Unexpected stain-stress rows: {family}:{profile}"
                    )
                if family == "somigp":
                    profiles.append(profile)
                evaluations += 1
    return {
        "families": sorted(roots),
        "profiles": profiles,
        "profile_count": len(profiles),
        "evaluations": evaluations,
    }


def audit_qualitative(outputs_root: Path) -> dict[str, object]:
    root = outputs_root.parent / "results" / "somigp" / "qualitative"
    index = read_json(root / "index.json")
    rows = index.get("rows")
    if not isinstance(rows, list) or len(rows) != 3:
        raise ValueError("Qualitative range must contain three traceable rows")
    expected = {
        "largest_improvement",
        "median_effect",
        "largest_degradation",
    }
    selections = {str(row["selection"]) for row in rows if isinstance(row, dict)}
    if selections != expected:
        raise ValueError("Qualitative selection labels are incomplete")
    for selection in expected:
        for suffix in (".png", "_instances.npz"):
            if not (root / f"{selection}{suffix}").is_file():
                raise ValueError(f"Missing qualitative artifact: {selection}{suffix}")
    for name in ("fig4_qualitative.png", "fig4_qualitative.pdf"):
        if not (root / name).is_file():
            raise ValueError(f"Missing qualitative composite: {name}")
    return {"rows": len(rows), "selections": sorted(selections)}


def scientific_gates(outputs_root: Path) -> dict[str, dict[str, object]]:
    rows = aggregate(comparisons(collect_scores(outputs_root)))
    index = {
        (str(row["comparison"]), str(row["split"]), str(row["metric"])): row
        for row in rows
    }

    def gate(
        comparison: str,
        metric: str,
        *,
        positive: bool = True,
    ) -> dict[str, object]:
        row = index[(comparison, "nuinsseg", metric)]
        difference = float(row["mean_difference"])
        better_seeds = int(row["better_seeds"])
        passed = difference > 0.0 if positive else difference < 0.0
        return {
            "passed": passed and better_seeds >= 2,
            "mean_difference": difference,
            "better_seeds": better_seeds,
            "seeds": int(row["seeds"]),
        }

    pannuke_row = index[
        ("somigp_minus_full", "pannuke_fold3", "mean_pq")
    ]
    pannuke_difference = float(pannuke_row["mean_difference"])
    pannuke_noninferiority = {
        "passed": pannuke_difference >= -0.005,
        "mean_difference": pannuke_difference,
        "noninferiority_margin": -0.005,
        "better_seeds": int(pannuke_row["better_seeds"]),
        "seeds": int(pannuke_row["seeds"]),
    }

    return {
        "external_mean_pq_vs_full": gate("somigp_minus_full", "mean_pq"),
        "pannuke_mean_pq_noninferiority_vs_full": pannuke_noninferiority,
        "mean_pq_vs_direct_gap": gate("somigp_minus_gap", "mean_pq"),
        "mean_pq_vs_no_orthogonalization": gate(
            "somigp_minus_no_orth", "mean_pq"
        ),
        "contact_success_vs_no_contact": gate(
            "somigp_minus_no_contact", "contact_pair_success_rate"
        ),
        "contact_merges_vs_no_contact": gate(
            "somigp_minus_no_contact", "contact_pair_merge_rate", positive=False
        ),
    }


def main() -> None:
    args = parse_args()
    runs = [
        audit_run(
            args.outputs_root,
            family,
            seed,
            sensitivity=family == "pannuke_somigp",
        )
        for family, seeds in EXPECTED_FAMILIES.items()
        for seed in seeds
    ]
    output = {
        "integrity_status": "passed",
        "runs": runs,
        "run_count": len(runs),
        "bootstraps": audit_bootstraps(args.outputs_root),
        "efficiency": audit_efficiency(args.outputs_root),
        "stain_stress": audit_stain_stress(args.outputs_root),
        "qualitative": audit_qualitative(args.outputs_root),
        "scientific_gates": scientific_gates(args.outputs_root),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import yaml
from PIL import Image, ImageDraw, ImageFont
from skimage.segmentation import find_boundaries

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from pathm.data import ManifestTaskDataset  # noqa: E402
from pathm.metrics import instance_diagnostic_scores  # noqa: E402
from pathm.models import build_model  # noqa: E402
from pathm.postprocessing import seeded_watershed_instances  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render a traceable Full versus SO-MIGP qualitative range"
    )
    parser.add_argument("--candidate-config", required=True, type=Path)
    parser.add_argument("--candidate-checkpoint", required=True, type=Path)
    parser.add_argument("--candidate-run-dir", required=True, type=Path)
    parser.add_argument("--reference-config", required=True, type=Path)
    parser.add_argument("--reference-checkpoint", required=True, type=Path)
    parser.add_argument("--reference-run-dir", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--minimum-contact-pairs", type=int, default=2)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return payload


def read_jsonl(path: Path) -> list[dict[str, object]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def threshold(run_dir: Path, task: str) -> float:
    return float(read_json(run_dir / "thresholds" / f"{task}.json")["selected_threshold"])


def indexed_metrics(path: Path) -> dict[str, dict[str, object]]:
    records = read_jsonl(path)
    if any("image_path" not in record for record in records):
        raise ValueError(f"Diagnostic records lack image provenance: {path}")
    indexed = {str(record["image_path"]): record for record in records}
    if len(indexed) != len(records):
        raise ValueError(f"Image paths are not unique: {path}")
    return indexed


def select_range(
    candidate: dict[str, dict[str, object]],
    reference: dict[str, dict[str, object]],
    minimum_contact_pairs: int,
) -> list[dict[str, object]]:
    common = sorted(set(candidate) & set(reference))
    rows: list[dict[str, object]] = []
    for image_path in common:
        candidate_row = candidate[image_path]
        reference_row = reference[image_path]
        pairs = int(candidate_row["contact_pairs"])
        if pairs != int(reference_row["contact_pairs"]):
            raise ValueError(f"Reference contact counts disagree: {image_path}")
        if pairs < minimum_contact_pairs:
            continue
        candidate_rate = float(candidate_row["contact_pair_successes"]) / pairs
        reference_rate = float(reference_row["contact_pair_successes"]) / pairs
        rows.append(
            {
                "image_path": image_path,
                "domain": str(candidate_row["domain"]),
                "contact_pairs": pairs,
                "candidate_rate": candidate_rate,
                "reference_rate": reference_rate,
                "effect": candidate_rate - reference_rate,
            }
        )
    if len(rows) < 3:
        raise ValueError("Fewer than three contact-rich images are available")
    rows.sort(key=lambda row: (float(row["effect"]), str(row["image_path"])))

    def available(preferred: list[dict[str, object]], used: list[dict[str, object]]) -> dict[str, object]:
        used_paths = {str(row["image_path"]) for row in used}
        used_domains = {str(row["domain"]) for row in used}
        for row in preferred:
            if str(row["image_path"]) not in used_paths and str(row["domain"]) not in used_domains:
                return row
        for row in preferred:
            if str(row["image_path"]) not in used_paths:
                return row
        raise ValueError("Could not select three distinct images")

    selected: list[dict[str, object]] = []
    largest = available(list(reversed(rows)), selected)
    selected.append(largest)
    smallest = available(rows, selected)
    selected.append(smallest)
    median_effect = float(np.median([float(row["effect"]) for row in rows]))
    median_order = sorted(rows, key=lambda row: abs(float(row["effect"]) - median_effect))
    median = available(median_order, selected)
    return [
        {"selection": "largest_improvement", **largest},
        {"selection": "median_effect", **median},
        {"selection": "largest_degradation", **smallest},
    ]


def load_model(config: dict[str, object], checkpoint: Path, device: torch.device) -> torch.nn.Module:
    model = build_model(config["model"]).to(device)  # type: ignore[arg-type]
    state = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    return model.eval()


def predict(
    model: torch.nn.Module,
    sample: dict[str, object],
    config: dict[str, object],
    detection_threshold: float,
    segmentation_threshold: float,
    device: torch.device,
) -> np.ndarray:
    image = sample["image"].unsqueeze(0).to(device)  # type: ignore[union-attr]
    target_id = sample["target_id"].reshape(1).to(device)  # type: ignore[union-attr]
    detection_id = torch.zeros(1, dtype=torch.long, device=device)
    segmentation_id = torch.ones(1, dtype=torch.long, device=device)
    with torch.inference_mode(), torch.autocast(
        device_type=device.type,
        dtype=torch.bfloat16,
        enabled=bool(config["training"].get("amp", True)) and device.type == "cuda",  # type: ignore[union-attr]
    ):
        detection = torch.sigmoid(
            model(image, detection_id, target_id)["logits"].float()
        )[0, 0]
        segmentation = torch.sigmoid(
            model(image, segmentation_id, target_id)["logits"].float()
        )[0, 0]
    return seeded_watershed_instances(
        segmentation.cpu().numpy(),
        detection.cpu().numpy(),
        segmentation_threshold=segmentation_threshold,
        detection_threshold=detection_threshold,
        detection_minimum_distance=int(
            config["evaluation"]["detection_minimum_distance"]  # type: ignore[index]
        ),
    )


def font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for path in (
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
    ):
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def overlay_boundary(
    image: np.ndarray, labels: np.ndarray, color: tuple[int, int, int]
) -> Image.Image:
    rendered = image.copy()
    rendered[find_boundaries(labels, mode="inner")] = color
    return Image.fromarray(rendered)


def error_overlay(
    image: np.ndarray, reference: np.ndarray, prediction: np.ndarray
) -> Image.Image:
    reference_foreground = reference > 0
    prediction_foreground = prediction > 0
    rendered = image.astype(np.float32) * 0.55
    rendered[reference_foreground & prediction_foreground] += np.array([30, 145, 30])
    rendered[~reference_foreground & prediction_foreground] += np.array([150, 20, 20])
    rendered[reference_foreground & ~prediction_foreground] += np.array([20, 70, 165])
    return Image.fromarray(np.clip(rendered, 0, 255).astype(np.uint8))


def panel(image: Image.Image, title: str, size: int = 384) -> Image.Image:
    rendered = image.resize((size, size), Image.Resampling.LANCZOS)
    output = Image.new("RGB", (size, size + 34), "white")
    output.paste(rendered, (0, 34))
    ImageDraw.Draw(output).text((8, 8), title, fill="#202225", font=font(15))
    return output


def model_label(name: str, diagnostics: dict[str, float]) -> str:
    successes = int(diagnostics["contact_pair_successes"])
    pairs = int(diagnostics["contact_pairs"])
    merges = int(diagnostics["contact_pair_merges"])
    return f"{name}: pairs {successes}/{pairs}, merges {merges}"


def main() -> None:
    args = parse_args()
    candidate_metrics = indexed_metrics(
        args.candidate_run_dir / "nuinsseg_ood" / "ood_test_instances.jsonl"
    )
    reference_metrics = indexed_metrics(
        args.reference_run_dir / "nuinsseg_ood" / "ood_test_instances.jsonl"
    )
    selections = select_range(
        candidate_metrics, reference_metrics, args.minimum_contact_pairs
    )
    candidate_config = yaml.safe_load(
        args.candidate_config.read_text(encoding="utf-8")
    )
    reference_config = yaml.safe_load(
        args.reference_config.read_text(encoding="utf-8")
    )
    candidate_config["data"]["manifest"] = str(args.manifest)
    reference_config["data"]["manifest"] = str(args.manifest)
    dataset = ManifestTaskDataset(
        args.manifest, "ood_test", operations=["segmentation"]
    )
    index_by_path = {record.image: index for index, record in enumerate(dataset.records)}
    device = torch.device(args.device)
    candidate_model = load_model(
        candidate_config, args.candidate_checkpoint, device
    )
    reference_model = load_model(
        reference_config, args.reference_checkpoint, device
    )
    candidate_thresholds = (
        threshold(args.candidate_run_dir, "detection"),
        threshold(args.candidate_run_dir, "segmentation"),
    )
    reference_thresholds = (
        threshold(args.reference_run_dir, "detection"),
        threshold(args.reference_run_dir, "segmentation"),
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rendered_rows: list[Image.Image] = []
    output_index: list[dict[str, object]] = []
    for row in selections:
        image_path = str(row["image_path"])
        sample = dataset[index_by_path[image_path]]
        candidate_prediction = predict(
            candidate_model,
            sample,
            candidate_config,
            *candidate_thresholds,
            device,
        )
        reference_prediction = predict(
            reference_model,
            sample,
            reference_config,
            *reference_thresholds,
            device,
        )
        reference = np.load(str(sample["label_path"]), allow_pickle=False)
        ignore_path = str(sample["ignore_path"])
        if ignore_path:
            ignore = np.load(ignore_path, allow_pickle=False).astype(bool)
            reference[ignore] = 0
            candidate_prediction[ignore] = 0
            reference_prediction[ignore] = 0
        original = np.asarray(Image.open(image_path).convert("RGB")).copy()
        candidate_diagnostics = instance_diagnostic_scores(reference, candidate_prediction)
        reference_diagnostics = instance_diagnostic_scores(reference, reference_prediction)
        panels = [
            panel(Image.fromarray(original), "H&E image"),
            panel(overlay_boundary(original, reference, (45, 170, 80)), "Reference"),
            panel(
                overlay_boundary(original, reference_prediction, (30, 175, 210)),
                model_label("Full", reference_diagnostics),
            ),
            panel(error_overlay(original, reference, reference_prediction), "Full error"),
            panel(
                overlay_boundary(original, candidate_prediction, (225, 80, 75)),
                model_label("SO-MIGP", candidate_diagnostics),
            ),
            panel(error_overlay(original, reference, candidate_prediction), "SO-MIGP error"),
        ]
        canvas = Image.new(
            "RGB", (sum(value.width for value in panels), panels[0].height), "white"
        )
        left = 0
        for value in panels:
            canvas.paste(value, (left, 0))
            left += value.width
        row_path = args.output_dir / f"{row['selection']}.png"
        canvas.save(row_path, dpi=(300, 300))
        np.savez_compressed(
            args.output_dir / f"{row['selection']}_instances.npz",
            reference=reference,
            full=reference_prediction,
            somigp=candidate_prediction,
        )
        rendered_rows.append(canvas)
        output_index.append(
            {
                **row,
                "rendered_row": str(row_path),
                "reference_diagnostics": reference_diagnostics,
                "candidate_diagnostics": candidate_diagnostics,
            }
        )
    composite = Image.new(
        "RGB",
        (max(row.width for row in rendered_rows), sum(row.height for row in rendered_rows)),
        "white",
    )
    top = 0
    for row in rendered_rows:
        composite.paste(row, (0, top))
        top += row.height
    composite.save(args.output_dir / "fig4_qualitative.png", dpi=(300, 300))
    composite.save(args.output_dir / "fig4_qualitative.pdf", resolution=300)
    (args.output_dir / "index.json").write_text(
        json.dumps(
            {
                "selection_policy": (
                    "largest, median, and smallest SO-MIGP minus Full contact-pair "
                    "success effects among NuInsSeg images with at least two contact pairs"
                ),
                "minimum_contact_pairs": args.minimum_contact_pairs,
                "candidate_thresholds": candidate_thresholds,
                "reference_thresholds": reference_thresholds,
                "rows": output_index,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

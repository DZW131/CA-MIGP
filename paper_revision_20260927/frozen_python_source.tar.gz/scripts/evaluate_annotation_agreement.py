from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from pathm.data import instance_centroids, load_manifest  # noqa: E402
from pathm.metrics import (  # noqa: E402
    binary_segmentation_scores,
    instance_scores,
    point_detection_scores,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate one annotation against another")
    parser.add_argument("--candidate-manifest", required=True, type=Path)
    parser.add_argument("--reference-manifest", required=True, type=Path)
    parser.add_argument("--candidate-name", required=True)
    parser.add_argument("--reference-name", required=True)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--matching-radius", type=float, default=6.0)
    return parser.parse_args()


def segmentation_records(manifest: Path) -> dict[str, object]:
    records = {
        record.patient_id: record
        for record in load_manifest(manifest)
        if record.operation == "segmentation"
    }
    if len(records) != 30:
        raise ValueError(f"Expected 30 unique segmentation records in {manifest}")
    return records


def write_jsonl(path: Path, records: list[dict[str, float | str]]) -> None:
    path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    candidate_records = segmentation_records(args.candidate_manifest.resolve())
    reference_records = segmentation_records(args.reference_manifest.resolve())
    if set(candidate_records) != set(reference_records):
        raise ValueError("Candidate and reference annotation sample IDs differ")

    task_records: list[dict[str, float | str]] = []
    instance_records: list[dict[str, float | str]] = []
    for sample_id in sorted(reference_records):
        candidate_record = candidate_records[sample_id]
        reference_record = reference_records[sample_id]
        if candidate_record.domain != reference_record.domain:
            raise ValueError(f"Domain mismatch for {sample_id}")
        candidate = np.load(candidate_record.label, allow_pickle=False)
        reference = np.load(reference_record.label, allow_pickle=False)
        if candidate.shape != reference.shape:
            raise ValueError(f"Annotation shape mismatch for {sample_id}")
        detection = point_detection_scores(
            instance_centroids(candidate),
            instance_centroids(reference),
            matching_radius=args.matching_radius,
        )
        segmentation = binary_segmentation_scores(
            torch.from_numpy(candidate > 0),
            torch.from_numpy(reference > 0),
        )
        common = {"sample_id": sample_id, "domain": reference_record.domain}
        task_records.extend(
            [
                {**common, "operation": "detection", **detection},
                {**common, "operation": "segmentation", **segmentation},
            ]
        )
        instance_records.append({**common, **instance_scores(reference, candidate)})

    detection = [record for record in task_records if record["operation"] == "detection"]
    segmentation = [
        record for record in task_records if record["operation"] == "segmentation"
    ]
    true_positive = sum(float(record["true_positive"]) for record in detection)
    false_positive = sum(float(record["false_positive"]) for record in detection)
    false_negative = sum(float(record["false_negative"]) for record in detection)
    precision = true_positive / max(true_positive + false_positive, 1.0)
    recall = true_positive / max(true_positive + false_negative, 1.0)
    instance_true_positive = sum(float(row["true_positive"]) for row in instance_records)
    instance_false_positive = sum(float(row["false_positive"]) for row in instance_records)
    instance_false_negative = sum(float(row["false_negative"]) for row in instance_records)
    matched_iou = sum(
        float(row["true_positive"]) * float(row["sq"]) for row in instance_records
    )
    global_dq = instance_true_positive / max(
        instance_true_positive + 0.5 * instance_false_positive + 0.5 * instance_false_negative,
        1.0,
    )
    global_sq = matched_iou / max(instance_true_positive, 1.0)
    summary = {
        "candidate_annotation": args.candidate_name,
        "reference_annotation": args.reference_name,
        "images": len(instance_records),
        "domains": len({str(record["domain"]) for record in instance_records}),
        "matching_radius": args.matching_radius,
        "detection_precision": precision,
        "detection_recall": recall,
        "detection_f1": 2.0 * precision * recall / max(precision + recall, 1e-12),
        "segmentation_dice": float(np.mean([row["dice"] for row in segmentation])),
        "segmentation_iou": float(np.mean([row["iou"] for row in segmentation])),
        "mean_aji_plus": float(np.mean([row["aji_plus"] for row in instance_records])),
        "mean_pq": float(np.mean([row["pq"] for row in instance_records])),
        "global_dq": global_dq,
        "global_sq": global_sq,
        "global_pq": global_dq * global_sq,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "per_image_tasks.jsonl", task_records)
    write_jsonl(args.output_dir / "ood_test_instances.jsonl", instance_records)
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()

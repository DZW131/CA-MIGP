from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import torch


PACKAGES = (
    "albumentations",
    "einops",
    "natsort",
    "numba",
    "numpy",
    "opencv-python-headless",
    "pydantic",
    "torch",
    "torchmetrics",
    "torchinfo",
    "wandb",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture the pinned CellViT environment")
    parser.add_argument("--external-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--encoder-weight", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git(repository: Path, *arguments: str) -> str:
    return subprocess.check_output(
        ["git", *arguments], cwd=repository, text=True
    ).strip()


def package_versions() -> dict[str, str | None]:
    output: dict[str, str | None] = {}
    for package in PACKAGES:
        try:
            output[package] = version(package)
        except PackageNotFoundError:
            output[package] = None
    return output


def main() -> None:
    args = parse_args()
    external_root = args.external_root.resolve()
    config = args.config.resolve()
    encoder_weight = args.encoder_weight.resolve()
    pip_check = subprocess.run(
        [sys.executable, "-m", "pip", "check"],
        check=False,
        capture_output=True,
        text=True,
    )
    result = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable": sys.executable,
        "packages": package_versions(),
        "torch_cuda_version": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "cellvit_git_commit": git(external_root, "rev-parse", "HEAD"),
        "cellvit_git_dirty": bool(git(external_root, "status", "--porcelain")),
        "config": str(config),
        "config_sha256": sha256(config),
        "encoder_weight": str(encoder_weight),
        "encoder_weight_bytes": encoder_weight.stat().st_size,
        "encoder_weight_sha256": sha256(encoder_weight),
        "pip_check_returncode": pip_check.returncode,
        "pip_check_stdout": pip_check.stdout.strip(),
        "pip_check_stderr": pip_check.stderr.strip(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import yaml


FIELDS = [
    "run_name",
    "seed",
    "architecture",
    "use_style_prompt",
    "style_prompt_mode",
    "factorized_task_prompt",
    "use_channel_prompt",
    "use_spatial_prompt",
    "parameters",
    "split",
    "detection_threshold",
    "segmentation_threshold",
    "detection_precision",
    "detection_recall",
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_dq",
    "global_sq",
    "global_pq",
    "manifest_sha256",
    "git_commit",
    "git_dirty",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a result ledger from run artifacts")
    parser.add_argument("--outputs", required=True, type=Path)
    parser.add_argument("--output-csv", required=True, type=Path)
    parser.add_argument("--output-json", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def collect_run(run_dir: Path) -> list[dict[str, object]]:
    summary = read_json(run_dir / "summary.json")
    if not summary:
        return []
    config_path = run_dir / "config.yaml"
    config = (
        yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if config_path.exists()
        else {}
    )
    model = config.get("model", {})
    architecture = model.get("architecture", "prompt_unified")
    thresholds = {
        "detection_threshold": read_json(run_dir / "thresholds" / "detection.json").get(
            "selected_threshold"
        ),
        "segmentation_threshold": read_json(
            run_dir / "thresholds" / "segmentation.json"
        ).get("selected_threshold"),
    }
    common = {
        "run_name": summary.get("run_name", run_dir.name),
        "seed": summary.get("seed"),
        "architecture": architecture,
        "use_style_prompt": model.get("use_style_prompt"),
        "style_prompt_mode": model.get("style_prompt_mode", "gram")
        if model.get("use_style_prompt", False)
        else None,
        "factorized_task_prompt": model.get("factorized_task_prompt"),
        "use_channel_prompt": model.get("use_channel_prompt"),
        "use_spatial_prompt": model.get("use_spatial_prompt"),
        "parameters": summary.get("parameters"),
        "manifest_sha256": summary.get("manifest_sha256"),
        "git_commit": summary.get("git_commit"),
        "git_dirty": summary.get("git_dirty"),
        **thresholds,
    }
    locations = {
        "pannuke_fold3": (
            run_dir / "frozen_test" / "task_summary.json",
            run_dir / "frozen_test" / "test_instance_summary.json",
        ),
        "nuinsseg_ood": (
            run_dir / "nuinsseg_ood" / "task_summary.json",
            run_dir / "nuinsseg_ood" / "ood_test_instance_summary.json",
        ),
        "cryonuseg_ann1_round1": (
            run_dir / "cryonuseg_ann1_round1" / "task_summary.json",
            run_dir / "cryonuseg_ann1_round1" / "ood_test_instance_summary.json",
        ),
        "cryonuseg_ann1_round2": (
            run_dir / "cryonuseg_ann1_round2" / "task_summary.json",
            run_dir / "cryonuseg_ann1_round2" / "ood_test_instance_summary.json",
        ),
        "cryonuseg_ann2": (
            run_dir / "cryonuseg_ann2" / "task_summary.json",
            run_dir / "cryonuseg_ann2" / "ood_test_instance_summary.json",
        ),
    }
    rows: list[dict[str, object]] = []
    for split, (task_path, instance_path) in locations.items():
        task = read_json(task_path)
        instance = read_json(instance_path)
        if not task and not instance:
            continue
        row = {**common, "split": split, **task, **instance}
        rows.append({field: row.get(field) for field in FIELDS})
    return rows


def main() -> None:
    args = parse_args()
    rows = [
        row
        for run_dir in sorted(path for path in args.outputs.iterdir() if path.is_dir())
        for row in collect_run(run_dir)
    ]
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"runs": len({row["run_name"] for row in rows}), "rows": len(rows)}))


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
import yaml
from PIL import Image

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from pathm.data.cellvit import (  # noqa: E402
    PANNUKE_NUCLEUS_TYPES,
    majority_instance_type_counts,
)


TISSUE_TYPES = (
    "Adrenal_gland",
    "Bile-duct",
    "Bladder",
    "Breast",
    "Cervix",
    "Colon",
    "Esophagus",
    "HeadNeck",
    "Kidney",
    "Liver",
    "Lung",
    "Ovarian",
    "Pancreatic",
    "Prostate",
    "Skin",
    "Stomach",
    "Testis",
    "Thyroid",
    "Uterus",
)
SOURCE_TO_CELLVIT_FOLD = {1: 0, 2: 1, 3: 2}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare the pinned CellViT PanNuke baseline")
    parser.add_argument("--parquet-root", required=True, type=Path)
    parser.add_argument("--processed-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    return parser.parse_args()


def decode_png(value: dict[str, object]) -> np.ndarray:
    payload = value.get("bytes")
    if not isinstance(payload, bytes):
        raise ValueError("Parquet image field does not contain bytes")
    with Image.open(io.BytesIO(payload)) as image:
        return np.asarray(image).copy()


def atomic_save_label(path: Path, instance_map: np.ndarray, type_map: np.ndarray) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.save(
            handle,
            {
                "inst_map": instance_map.astype(np.int32, copy=False),
                "type_map": type_map.astype(np.int32, copy=False),
            },
        )
    temporary.replace(path)


def hardlink_verified(source: Path, target: Path) -> None:
    if target.exists():
        if not os.path.samefile(source, target):
            raise ValueError(f"Existing image is not linked to its verified source: {target}")
        return
    os.link(source, target)


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    parquet_files = sorted(args.parquet_root.glob("fold*/*.parquet"))
    if len(parquet_files) != 6:
        raise ValueError(f"Expected six PanNuke Parquet shards, found {len(parquet_files)}")

    fold_types: dict[int, list[dict[str, object]]] = {fold: [] for fold in range(3)}
    fold_counts: dict[int, list[dict[str, object]]] = {fold: [] for fold in range(3)}
    tissue_totals = {name: 0 for name in TISSUE_TYPES}
    nucleus_totals = {name: 0 for name in PANNUKE_NUCLEUS_TYPES}
    digest = hashlib.sha256()

    for cellvit_fold in range(3):
        (args.output_root / f"fold{cellvit_fold}" / "images").mkdir(
            parents=True, exist_ok=True
        )
        (args.output_root / f"fold{cellvit_fold}" / "labels").mkdir(
            parents=True, exist_ok=True
        )

    for parquet_path in parquet_files:
        parquet = pq.ParquetFile(parquet_path)
        for batch in parquet.iter_batches(batch_size=64):
            for row in batch.to_pylist():
                source_fold = int(row["fold"])
                cellvit_fold = SOURCE_TO_CELLVIT_FOLD[source_fold]
                sample_id = str(row["sample_id"])
                tissue_name = str(row["tissue_name"])
                if tissue_name not in tissue_totals:
                    raise ValueError(f"Unknown PanNuke tissue: {tissue_name}")

                instance_map = decode_png(row["inst_map"])
                type_map = decode_png(row["type_map"])
                verified_instance_path = (
                    args.processed_root / "instances" / f"fold{source_fold}" / f"{sample_id}.npy"
                )
                verified_instance = np.load(verified_instance_path, allow_pickle=False)
                if not np.array_equal(instance_map, verified_instance):
                    raise ValueError(f"Instance mismatch for {sample_id}")

                image_source = (
                    args.processed_root / "images" / f"fold{source_fold}" / f"{sample_id}.png"
                )
                output_fold = args.output_root / f"fold{cellvit_fold}"
                image_name = f"{sample_id}.png"
                hardlink_verified(image_source, output_fold / "images" / image_name)
                atomic_save_label(
                    output_fold / "labels" / f"{sample_id}.npy",
                    instance_map,
                    type_map,
                )

                counts = majority_instance_type_counts(instance_map, type_map)
                count_row: dict[str, object] = {"Image": image_name}
                for name, count in zip(PANNUKE_NUCLEUS_TYPES, counts, strict=True):
                    count_row[name] = count
                    nucleus_totals[name] += count
                fold_counts[cellvit_fold].append(count_row)
                fold_types[cellvit_fold].append({"img": image_name, "type": tissue_name})
                tissue_totals[tissue_name] += 1
                digest.update(
                    f"{cellvit_fold}\t{sample_id}\t{tissue_name}\t{','.join(map(str, counts))}\n".encode()
                )

    for fold in range(3):
        fold_root = args.output_root / f"fold{fold}"
        fold_counts[fold].sort(key=lambda row: str(row["Image"]))
        fold_types[fold].sort(key=lambda row: str(row["img"]))
        write_csv(
            fold_root / "cell_count.csv",
            ["Image", *PANNUKE_NUCLEUS_TYPES],
            fold_counts[fold],
        )
        write_csv(fold_root / "types.csv", ["img", "type"], fold_types[fold])

    dataset_config = {
        "tissue_types": {name: index for index, name in enumerate(TISSUE_TYPES)},
        "nuclei_types": {
            "Background": 0,
            **{name: index + 1 for index, name in enumerate(PANNUKE_NUCLEUS_TYPES)},
        },
    }
    weight_config = {"tissue": tissue_totals, "nuclei": nucleus_totals}
    for name, value in (
        ("dataset_config.yaml", dataset_config),
        ("weight_config.yaml", weight_config),
    ):
        (args.output_root / name).write_text(
            yaml.safe_dump(value, sort_keys=False), encoding="utf-8"
        )

    provenance = {
        "source": "MedOtter/PanNuke",
        "source_repository_commit": "aaefe225badffc07484359f817d0f10f1854f880",
        "fold_mapping": {"fold1": "fold0", "fold2": "fold1", "fold3": "fold2"},
        "records_per_fold": {
            f"fold{fold}": len(fold_types[fold]) for fold in range(3)
        },
        "records": sum(len(rows) for rows in fold_types.values()),
        "index_sha256": digest.hexdigest(),
        "images": "hardlinked_to_verified_pathm_processed_copy",
        "instances": "decoded_from_parquet_and_exactly_matched_to_verified_copy",
    }
    (args.output_root / "provenance.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(provenance, sort_keys=True))


if __name__ == "__main__":
    main()

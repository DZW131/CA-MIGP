from __future__ import annotations

import argparse
import copy
import gc
import json
import logging
import os
import sys
from pathlib import Path

import torch
import yaml
from torch.utils.data import DataLoader


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="One official CellViT training-step smoke test")
    parser.add_argument("--external-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--device", default="cuda:0")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.batch_size <= 0:
        raise ValueError("batch size must be positive")
    if not torch.cuda.is_available() or not args.device.startswith("cuda"):
        raise RuntimeError("CellViT smoke test requires CUDA")
    external_root = args.external_root.resolve()
    config = yaml.safe_load(args.config.resolve().read_text(encoding="utf-8"))
    os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")
    sys.path.insert(0, str(external_root))

    from cell_segmentation.experiments.experiment_cellvit_pannuke import (  # noqa: PLC0415
        ExperimentCellVitPanNuke,
    )

    experiment = ExperimentCellVitPanNuke(default_conf=config)
    experiment.run_conf = copy.deepcopy(config)
    experiment.run_conf["dataset_config"] = experiment.dataset_config
    train_transforms, val_transforms = experiment.get_transforms(
        experiment.run_conf["transformations"],
        input_shape=experiment.run_conf["data"].get("input_shape", 256),
    )
    train_dataset, val_dataset = experiment.get_datasets(
        train_transforms=train_transforms,
        val_transforms=val_transforms,
    )
    loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=False, num_workers=0)
    batch = next(iter(loader))

    model = experiment.get_train_model(
        pretrained_encoder=experiment.run_conf["model"]["pretrained_encoder"],
        pretrained_model=experiment.run_conf["model"].get("pretrained"),
        backbone_type=experiment.run_conf["model"]["backbone"],
        shared_decoders=experiment.run_conf["model"].get("shared_decoders", False),
        regression_loss=experiment.run_conf["model"].get("regression_loss", False),
    ).to(args.device)
    loss_fn_dict = experiment.get_loss_fn(experiment.run_conf["loss"])
    optimizer = experiment.get_optimizer(
        model,
        experiment.run_conf["training"]["optimizer"],
        experiment.run_conf["training"]["optimizer_hyperparameter"],
    )
    scheduler = experiment.get_scheduler(
        experiment.run_conf["training"]["scheduler"]["scheduler_type"],
        optimizer,
    )
    trainable_parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    before = [parameter.detach().clone() for parameter in trainable_parameters]
    trainer_class = experiment.get_trainer()
    smoke_dir = args.output.resolve().parent
    smoke_dir.mkdir(parents=True, exist_ok=True)
    trainer = trainer_class(
        model=model,
        loss_fn_dict=loss_fn_dict,
        optimizer=optimizer,
        scheduler=scheduler,
        device=args.device,
        logger=logging.getLogger("cellvit-smoke"),
        logdir=smoke_dir,
        num_classes=int(experiment.run_conf["data"]["num_nuclei_classes"]),
        dataset_config=experiment.dataset_config,
        experiment_config=experiment.run_conf,
        early_stopping=None,
        log_images=False,
        magnification=int(experiment.run_conf["data"].get("magnification", 40)),
        mixed_precision=bool(experiment.run_conf["training"].get("mixed_precision", False)),
    )
    torch.cuda.reset_peak_memory_stats()
    model.train()
    parameter_update = 0.0
    smoke_steps = 0
    scale_history: list[dict[str, float]] = []
    maximum_smoke_steps = 16
    for smoke_steps in range(1, maximum_smoke_steps + 1):
        scale_before = float(trainer.scaler.get_scale()) if trainer.scaler else 1.0
        metrics, _ = trainer.train_step(
            batch, smoke_steps - 1, maximum_smoke_steps, return_example_images=False
        )
        scale_after = float(trainer.scaler.get_scale()) if trainer.scaler else 1.0
        scale_history.append({"before": scale_before, "after": scale_after})
        parameter_update = max(
            float((parameter.detach() - initial).abs().max().cpu())
            for parameter, initial in zip(trainable_parameters, before, strict=True)
        )
        if parameter_update > 0.0:
            break
    training_peak_memory = torch.cuda.max_memory_allocated()
    if parameter_update == 0.0:
        raise RuntimeError(
            "CellViT smoke steps did not update any trainable parameter; "
            f"scales={scale_history}; metrics={metrics}"
        )
    if not all(torch.isfinite(parameter).all() for parameter in model.parameters()):
        raise RuntimeError("CellViT smoke step produced non-finite parameters")
    del batch, before
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    model.eval()
    with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.float16):
        external_predictions = model(torch.zeros(1, 3, 512, 512, device=args.device))
    for branch in ("nuclei_binary_map", "hv_map", "nuclei_type_map"):
        if tuple(external_predictions[branch].shape[-2:]) != (512, 512):
            raise RuntimeError(f"Unexpected 512-pixel output for {branch}")
    external_peak_memory = torch.cuda.max_memory_allocated()
    output = {
        "status": "passed",
        "device": torch.cuda.get_device_name(torch.device(args.device)),
        "batch_size": args.batch_size,
        "train_images": len(train_dataset),
        "validation_images": len(val_dataset),
        "model_class": type(model).__name__,
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "trainable_parameters": sum(
            parameter.numel() for parameter in model.parameters() if parameter.requires_grad
        ),
        "parameter_update_max_abs": parameter_update,
        "grad_scaler_history": scale_history,
        "training_steps": smoke_steps,
        "training_peak_cuda_memory_bytes": training_peak_memory,
        "external_512_peak_cuda_memory_bytes": external_peak_memory,
        "scheduler_gamma": float(experiment.run_conf["training"]["scheduler"]["gamma"]),
        "metric_keys": sorted(metrics),
    }
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()

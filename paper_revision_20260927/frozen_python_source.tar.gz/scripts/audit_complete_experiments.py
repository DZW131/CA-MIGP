from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path


SEEDS = (17, 23, 42)
FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
    "pannuke_ablation_constant_style",
    "pannuke_ablation_diagonal_style",
    "pannuke_ablation_no_spatial",
    "pannuke_ablation_no_modulation",
    "pannuke_multihead_unet",
    "pannuke_full_prompt_hed",
    "pannuke_ablation_no_style_hed",
)
ALTERNATE_ANNOTATION_FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
)
MANIFEST_SHA256 = "2049e5d760805b7ed4c2aaff8b8ee2a1297c0607188a085b5d1b200f3c954b5c"
CELLVIT_COMMIT = "05097e18e3d194a65121042f631b5753069f5ee3"
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)
EVALUATIONS = {
    "frozen_test": ("fold3", 5444, 2722, "test_instances.jsonl"),
    "nuinsseg_ood": ("nuinsseg", 1330, 665, "ood_test_instances.jsonl"),
    "cryonuseg_ann1_round1": (
        "cryonuseg_ann1_round1",
        60,
        30,
        "ood_test_instances.jsonl",
    ),
}
ALTERNATE_EVALUATIONS = {
    "cryonuseg_ann1_round2": (
        "cryonuseg_ann1_round2",
        60,
        30,
        "ood_test_instances.jsonl",
    ),
    "cryonuseg_ann2": ("cryonuseg_ann2", 60, 30, "ood_test_instances.jsonl"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit the complete manuscript experiment matrix")
    parser.add_argument("--verified-root", required=True, type=Path)
    parser.add_argument("--per-image-root", required=True, type=Path)
    return parser.parse_args()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_json(path: Path) -> dict[str, object]:
    require(path.is_file(), f"Missing artifact: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"Expected JSON object: {path}")
    return value


def read_json_list(path: Path) -> list[object]:
    require(path.is_file(), f"Missing artifact: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, list), f"Expected JSON list: {path}")
    return value


def count_jsonl(path: Path) -> int:
    require(path.is_file(), f"Missing per-image artifact: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return sum(1 for line in handle if line.strip())


def read_jsonl(path: Path) -> list[dict[str, object]]:
    require(path.is_file(), f"Missing per-image artifact: {path}")
    with path.open("r", encoding="utf-8") as handle:
        records = [json.loads(line) for line in handle if line.strip()]
    require(all(isinstance(record, dict) for record in records), f"Bad JSONL: {path}")
    return records


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def audit_metric_summaries(task_path: Path, instance_path: Path, images: int) -> None:
    task = read_json(task_path)
    instance = read_json(instance_path)
    if "images" in task:
        require(int(task["images"]) == images, f"Image count mismatch: {task_path}")
    require(int(instance.get("images", -1)) == images, f"Image count mismatch: {instance_path}")
    merged = {**task, **instance}
    for metric in METRICS:
        value = float(merged.get(metric, math.nan))
        require(math.isfinite(value) and 0.0 <= value <= 1.0, f"Invalid {metric}: {task_path}")


def audit_bootstrap(path: Path, *, expected_groups: int) -> None:
    result = read_json(path)
    require(result.get("replicates") == 10000, f"Bootstrap replicate mismatch: {path}")
    require(result.get("seed") == 2026, f"Bootstrap seed mismatch: {path}")
    require(result.get("groups") == expected_groups, f"Bootstrap group mismatch: {path}")
    metrics = result.get("metrics")
    require(isinstance(metrics, dict) and metrics, f"Missing bootstrap metrics: {path}")
    for metric, interval in metrics.items():
        require(isinstance(interval, dict), f"Malformed bootstrap metric {metric}: {path}")
        intervals = (
            [interval]
            if "ci95_low" in interval
            else [
                value
                for value in interval.values()
                if isinstance(value, dict) and "ci95_low" in value
            ]
        )
        require(intervals, f"Missing bootstrap interval {metric}: {path}")
        for nested_interval in intervals:
            low = float(nested_interval.get("ci95_low", math.nan))
            high = float(nested_interval.get("ci95_high", math.nan))
            estimate = float(nested_interval.get("estimate", math.nan))
            require(
                all(math.isfinite(value) for value in (low, high, estimate))
                and low <= high,
                f"Invalid bootstrap interval {metric}: {path}",
            )


def audit_evaluation(
    verified_run: Path,
    per_image_run: Path,
    relative_dir: str,
    label: str,
    task_rows: int,
    instance_rows: int,
    instance_name: str,
    *,
    summary_prefix: str = "",
) -> int:
    audit_metric_summaries(
        verified_run / f"{summary_prefix}{label}_task_summary.json",
        verified_run / f"{summary_prefix}{label}_instance_summary.json",
        instance_rows,
    )
    require(
        count_jsonl(per_image_run / relative_dir / "per_image_tasks.jsonl") == task_rows,
        f"Task row mismatch: {per_image_run / relative_dir}",
    )
    require(
        count_jsonl(per_image_run / relative_dir / instance_name) == instance_rows,
        f"Instance row mismatch: {per_image_run / relative_dir}",
    )
    return 2


def audit_mismatch_donors(
    per_image_run: Path,
    relative_dir: str,
    instance_name: str,
    *,
    require_cross_domain: bool,
) -> None:
    for name in ("per_image_tasks.jsonl", instance_name):
        path = per_image_run / relative_dir / name
        for record in read_jsonl(path):
            require(
                record.get("image_path") != record.get("style_source_image"),
                f"Self style donor: {path}",
            )
            if require_cross_domain:
                require(
                    record.get("domain") != record.get("style_source_domain"),
                    f"Same-domain style donor: {path}",
                )


def audit_pathm_runs(verified_root: Path, per_image_root: Path) -> tuple[int, int]:
    runs = 0
    per_image_files = 0
    for family in FAMILIES:
        for seed in SEEDS:
            run_name = f"{family}_seed{seed}"
            verified_run = verified_root / run_name
            per_image_run = per_image_root / run_name
            summary = read_json(verified_run / "train_summary.json")
            require(summary.get("status") == "completed", f"Incomplete run: {run_name}")
            require(summary.get("seed") == seed, f"Seed mismatch: {run_name}")
            require(summary.get("epochs") == 50, f"Epoch mismatch: {run_name}")
            history = summary.get("history")
            require(isinstance(history, list) and len(history) == 50, f"History mismatch: {run_name}")
            require(summary.get("git_dirty") is False, f"Dirty training tree: {run_name}")
            require(summary.get("manifest_sha256") == MANIFEST_SHA256, f"Manifest mismatch: {run_name}")
            require(int(summary.get("parameters", 0)) > 0, f"Missing parameter count: {run_name}")
            for task in ("detection", "segmentation"):
                threshold = read_json(verified_run / f"val_{task}_threshold.json")
                require(threshold.get("selection_split") == "val", f"Threshold leakage: {run_name}/{task}")
                value = float(threshold.get("selected_threshold", math.nan))
                require(0.0 < value < 1.0, f"Invalid threshold: {run_name}/{task}")
            for relative_dir, values in EVALUATIONS.items():
                per_image_files += audit_evaluation(
                    verified_run, per_image_run, relative_dir, *values
                )
            if family in ALTERNATE_ANNOTATION_FAMILIES:
                for relative_dir, values in ALTERNATE_EVALUATIONS.items():
                    per_image_files += audit_evaluation(
                        verified_run, per_image_run, relative_dir, *values
                    )
            if family == "pannuke_full_prompt":
                for relative_dir, values in EVALUATIONS.items():
                    per_image_files += audit_evaluation(
                        verified_run,
                        per_image_run,
                        f"style_mismatch/{relative_dir}",
                        *values,
                        summary_prefix="style_mismatch_",
                    )
                    audit_mismatch_donors(
                        per_image_run,
                        f"style_mismatch/{relative_dir}",
                        values[3],
                        require_cross_domain=relative_dir != "frozen_test",
                    )
            runs += 1
    return runs, per_image_files


def audit_pathm_bootstraps(verified_root: Path) -> int:
    checked = 0
    for seed in SEEDS:
        run = verified_root / f"pannuke_full_prompt_seed{seed}"
        names = (
            "fold3_vs_no_style_paired_bootstrap.json",
            "nuinsseg_vs_no_style_paired_bootstrap.json",
            "fold3_vs_constant_style_paired_bootstrap.json",
            "nuinsseg_vs_constant_style_paired_bootstrap.json",
            "fold3_vs_diagonal_style_paired_bootstrap.json",
            "nuinsseg_vs_diagonal_style_paired_bootstrap.json",
            "fold3_vs_style_mismatch_paired_bootstrap.json",
            "nuinsseg_vs_style_mismatch_paired_bootstrap.json",
            "cryonuseg_ann1_round1_vs_no_style_paired_bootstrap.json",
            "cryonuseg_ann1_round1_vs_constant_style_paired_bootstrap.json",
            "cryonuseg_ann1_round1_vs_diagonal_style_paired_bootstrap.json",
            "cryonuseg_ann1_round1_vs_style_mismatch_paired_bootstrap.json",
            "cryonuseg_ann1_round2_vs_no_style_paired_bootstrap.json",
            "cryonuseg_ann2_vs_no_style_paired_bootstrap.json",
            "cryonuseg_ann1_round1_factorial_bootstrap.json",
        )
        for name in names:
            if name.startswith("fold3"):
                expected_groups = 2722
            elif name.startswith("nuinsseg"):
                expected_groups = 31
            else:
                expected_groups = 10
            audit_bootstrap(run / name, expected_groups=expected_groups)
            checked += 1
    return checked


def audit_annotation_agreement(verified_root: Path, per_image_root: Path) -> int:
    for comparison in ("ann1_round2_vs_round1", "ann2_vs_ann1_round1"):
        root = verified_root / "cryonuseg_annotation_agreement" / comparison
        summary = read_json(root / "summary.json")
        require(summary.get("images") == 30 and summary.get("domains") == 10, f"Agreement sample mismatch: {comparison}")
        audit_bootstrap(root / "bootstrap.json", expected_groups=10)
        per_image = per_image_root / "cryonuseg_annotation_agreement" / comparison
        require(count_jsonl(per_image / "per_image_tasks.jsonl") == 60, f"Agreement task rows: {comparison}")
        require(
            count_jsonl(per_image / "ood_test_instances.jsonl") == 30,
            f"Agreement instance rows: {comparison}",
        )
    return 2


def audit_stain_and_efficiency(verified_root: Path, per_image_root: Path) -> tuple[int, int]:
    profiles = tuple(
        f"h{hematoxylin}_e{eosin}"
        for hematoxylin in ("0.7", "1.0", "1.3")
        for eosin in ("0.7", "1.0", "1.3")
    )
    per_image_files = 0
    for model in ("full_prompt", "no_style"):
        for profile in profiles:
            verified = verified_root / "stain_robustness_seed17" / model / profile
            audit_metric_summaries(
                verified / "task_summary.json",
                verified / "test_instance_summary.json",
                2722,
            )
            per_image = per_image_root / "stain_robustness" / model / profile
            require(
                count_jsonl(per_image / "per_image_tasks.jsonl") == 5444,
                f"Stain task rows: {model}/{profile}",
            )
            require(
                count_jsonl(per_image / "test_instances.jsonl") == 2722,
                f"Stain instance rows: {model}/{profile}",
            )
            per_image_files += 2
    efficiency = verified_root / "efficiency_seed17"
    for name in (
        "full_prompt_seed17.json",
        "no_style_seed17.json",
        "multihead_seed17.json",
        "specialist_pair_seed17.json",
    ):
        result = read_json(efficiency / name)
        require(float(result.get("parameters", 0)) > 0, f"Efficiency parameters: {name}")
        require(
            float(result.get("latency_ms_per_image", 0)) > 0,
            f"Efficiency latency: {name}",
        )
    return 18, per_image_files


def audit_cellvit(verified_root: Path, per_image_root: Path) -> tuple[int, int]:
    verified_run = verified_root / "cellvit256_fold1_baseline"
    per_image_run = per_image_root / "cellvit256_fold1_baseline"
    state = read_json(verified_run / "state.json")
    smoke = read_json(verified_run / "smoke.json")
    efficiency = read_json(verified_run / "efficiency.json")
    environment = read_json(verified_run / "environment.json")
    require(state.get("status") == "completed", "CellViT training incomplete")
    require(state.get("epochs") == 130 and state.get("completed_epoch_index") == 129, "CellViT epoch mismatch")
    best_epoch = int(state.get("best_checkpoint_epoch_index", -1))
    require(0 <= best_epoch < 130, "CellViT best-checkpoint epoch mismatch")
    for key in ("checkpoint_sha256", "best_checkpoint_sha256"):
        value = state.get(key)
        require(
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value),
            f"Invalid CellViT {key}",
        )
    require(state.get("cellvit_git_commit") == CELLVIT_COMMIT, "CellViT commit mismatch")
    require(state.get("cellvit_git_dirty") is False, "Dirty CellViT training repository")
    launch_commit = state.get("pathm_git_commit_at_launch")
    require(
        isinstance(launch_commit, str)
        and len(launch_commit) == 40
        and all(character in "0123456789abcdef" for character in launch_commit),
        "Invalid PathM launch commit for CellViT",
    )
    require(state.get("pathm_git_dirty_at_launch") is False, "Dirty CellViT wrapper launch")
    source_hashes = state.get("source_sha256_at_launch")
    require(isinstance(source_hashes, dict) and len(source_hashes) == 4, "CellViT source hashes")
    require(
        all(
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value)
            for value in source_hashes.values()
        ),
        "Invalid CellViT source hash",
    )
    require(smoke.get("status") == "passed", "CellViT smoke test failed")
    require(float(smoke.get("parameter_update_max_abs", 0.0)) > 0.0, "CellViT smoke update missing")
    require(efficiency.get("checkpoint_architecture") == "CellViT256Shared", "CellViT efficiency architecture")
    require(float(efficiency.get("parameters", 0)) > 0, "CellViT efficiency parameters")
    require(float(efficiency.get("latency_ms_per_image", 0)) > 0, "CellViT efficiency latency")
    require(environment.get("cellvit_git_commit") == CELLVIT_COMMIT, "CellViT environment commit")
    require(environment.get("cellvit_git_dirty") is False, "Dirty CellViT environment")
    require(environment.get("pip_check_returncode") == 0, "CellViT pip check failed")
    require(
        environment.get("encoder_weight_sha256")
        == "6960cd5a8657dc8bb214671aa0c6dbd3f5b698e84386884955836487ddc89e24",
        "CellViT encoder weight mismatch",
    )
    evaluations = {
        "pannuke_fold3": (5444, 2722, "test_instances.jsonl"),
        "nuinsseg_ood": (1330, 665, "ood_test_instances.jsonl"),
        "cryonuseg_ann1_round1": (60, 30, "ood_test_instances.jsonl"),
        "cryonuseg_ann1_round2": (60, 30, "ood_test_instances.jsonl"),
        "cryonuseg_ann2": (60, 30, "ood_test_instances.jsonl"),
    }
    per_image_files = 0
    for label, (task_rows, instance_rows, instance_name) in evaluations.items():
        root = verified_run / label
        audit_metric_summaries(root / "task_summary.json", root / "instance_summary.json", instance_rows)
        metadata = read_json(root / "metadata.json")
        require(metadata.get("cellvit_git_commit") == CELLVIT_COMMIT, f"CellViT metadata commit: {label}")
        require(metadata.get("checkpoint_architecture") == "CellViT256Shared", f"CellViT architecture: {label}")
        require(count_jsonl(per_image_run / label / "per_image_tasks.jsonl") == task_rows, f"CellViT task rows: {label}")
        require(count_jsonl(per_image_run / label / instance_name) == instance_rows, f"CellViT instance rows: {label}")
        per_image_files += 2
    bootstraps = 0
    for label in ("pannuke_fold3", "nuinsseg_ood", "cryonuseg_ann1_round1"):
        expected_groups = {
            "pannuke_fold3": 2722,
            "nuinsseg_ood": 31,
            "cryonuseg_ann1_round1": 10,
        }[label]
        for seed in SEEDS:
            audit_bootstrap(
                verified_run / f"{label}_vs_full_seed{seed}_paired_bootstrap.json",
                expected_groups=expected_groups,
            )
            bootstraps += 1
    return bootstraps, per_image_files


def audit_aggregates(verified_root: Path) -> int:
    aggregate = verified_root / "aggregate"
    expected = {
        "multiseed_summary.json": 162,
        "multiseed_comparisons.json": 180,
        "stain_robustness.json": 27,
        "annotation_model_scores.json": 18,
        "annotation_differences.json": 21,
        "annotation_summary.json": 65,
        "human_agreement.json": 2,
        "domain_effect_summary.json": 90,
        "strong_baseline_scores.json": 72,
        "strong_baseline_differences.json": 54,
        "strong_baseline_difference_summary.json": 18,
        "strong_baseline_bootstrap.json": 45,
    }
    for name, rows in expected.items():
        require(len(read_json_list(aggregate / name)) == rows, f"Aggregate row mismatch: {name}")
    provenance = read_json(aggregate / "training_provenance_audit.json")
    require(provenance.get("status") == "passed", "Training provenance audit failed")
    return len(expected) + 1


def audit_export_manifest(verified_root: Path, per_image_root: Path) -> int:
    export_root = verified_root.parent
    require(per_image_root.parent == export_root, "Artifact roots do not share a parent")
    manifest = read_json(verified_root / "artifact_export_manifest.json")
    require(manifest.get("pathm_runs") == 27, "Export manifest PathM run count mismatch")
    require(manifest.get("cellvit_exported") is True, "CellViT missing from export manifest")
    require(
        manifest.get("annotation_agreement_comparisons") == 2,
        "Annotation agreement missing from export manifest",
    )
    require(manifest.get("stain_profiles") == 18, "Stain profiles missing from export manifest")
    require(manifest.get("efficiency_files") == 4, "Efficiency files missing from export manifest")
    files = manifest.get("files")
    require(isinstance(files, list) and files, "Empty export manifest")
    destinations: set[str] = set()
    for record in files:
        require(isinstance(record, dict), "Malformed export record")
        destination = str(record["destination"])
        require(destination not in destinations, f"Duplicate export destination: {destination}")
        destinations.add(destination)
        path = export_root / destination
        require(path.is_file(), f"Missing exported file: {path}")
        require(path.stat().st_size == int(record["bytes"]), f"Export size mismatch: {path}")
        require(sha256(path) == record["sha256"], f"Export hash mismatch: {path}")
    return len(files)


def main() -> None:
    args = parse_args()
    verified_root = args.verified_root.resolve()
    per_image_root = args.per_image_root.resolve()
    runs, pathm_per_image = audit_pathm_runs(verified_root, per_image_root)
    pathm_bootstraps = audit_pathm_bootstraps(verified_root)
    agreement = audit_annotation_agreement(verified_root, per_image_root)
    stain_profiles, stain_per_image = audit_stain_and_efficiency(
        verified_root, per_image_root
    )
    cellvit_bootstraps, cellvit_per_image = audit_cellvit(verified_root, per_image_root)
    aggregate_files = audit_aggregates(verified_root)
    export_files = audit_export_manifest(verified_root, per_image_root)
    print(
        json.dumps(
            {
                "aggregate_files": aggregate_files,
                "annotation_agreement_comparisons": agreement,
                "bootstrap_files": pathm_bootstraps + cellvit_bootstraps,
                "export_manifest_files": export_files,
                "pathm_runs": runs,
                "per_image_files": pathm_per_image + cellvit_per_image + stain_per_image,
                "stain_profiles": stain_profiles,
                "status": "passed",
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

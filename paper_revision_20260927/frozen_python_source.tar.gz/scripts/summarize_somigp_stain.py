from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize SO-MIGP stain stress")
    parser.add_argument("--outputs-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return payload


def profile_scores(root: Path, profile: str) -> dict[str, float]:
    merged = {
        **read_json(root / profile / "task_summary.json"),
        **read_json(root / profile / "test_instance_summary.json"),
    }
    return {metric: float(merged[metric]) for metric in METRICS}


def collect(outputs_root: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    somigp_root = outputs_root / "somigp_stain_stress"
    full_root = outputs_root / "stain_robustness" / "full_prompt"
    for hematoxylin in (0.7, 1.0, 1.3):
        for eosin in (0.7, 1.0, 1.3):
            profile = f"h{hematoxylin}_e{eosin}"
            scores = {
                "somigp": profile_scores(somigp_root, profile),
                "full": profile_scores(full_root, profile),
            }
            for family in ("full", "somigp"):
                rows.append(
                    {
                        "family": family,
                        "profile": profile,
                        "hematoxylin_scale": hematoxylin,
                        "eosin_scale": eosin,
                        **scores[family],
                    }
                )
            rows.append(
                {
                    "family": "somigp_minus_full",
                    "profile": profile,
                    "hematoxylin_scale": hematoxylin,
                    "eosin_scale": eosin,
                    **{
                        metric: scores["somigp"][metric] - scores["full"][metric]
                        for metric in METRICS
                    },
                }
            )
    return rows


def main() -> None:
    args = parse_args()
    rows = collect(args.outputs_root)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "somigp_stain_stress.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    with (args.output_dir / "somigp_stain_stress.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"rows": len(rows)}, sort_keys=True))


if __name__ == "__main__":
    main()

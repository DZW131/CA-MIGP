from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPOSITORY_ROOT / "src"))

from pathm.data import ManifestTaskDataset, instance_centroids  # noqa: E402
from pathm.metrics import (  # noqa: E402
    binary_segmentation_scores,
    instance_scores,
    point_detection_scores,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate CellViT with PathM metrics")
    parser.add_argument("--external-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--split", choices=("test", "ood_test"), required=True)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--num-workers", type=int, default=8)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--magnification", type=int, choices=(20, 40), default=40)
    parser.add_argument("--matching-radius", type=float, default=6.0)
    return parser.parse_args()


def load_cellvit(
    external_root: Path,
    config: dict[str, object],
    checkpoint_path: Path,
    device: torch.device,
) -> tuple[torch.nn.Module, dict[str, object]]:
    os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")
    sys.path.insert(0, str(external_root))
    from models.segmentation.cell_segmentation.cellvit import CellViT256  # noqa: PLC0415
    from models.segmentation.cell_segmentation.cellvit_shared import (  # noqa: PLC0415
        CellViT256Shared,
    )

    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    architecture = str(checkpoint["arch"])
    model_config = config["model"]
    data_config = config["data"]
    training_config = config["training"]
    assert isinstance(model_config, dict)
    assert isinstance(data_config, dict)
    assert isinstance(training_config, dict)
    classes = {
        "CellViT256": CellViT256,
        "CellViT256Shared": CellViT256Shared,
    }
    if architecture not in classes:
        raise ValueError(f"Unsupported CellViT checkpoint architecture: {architecture}")
    model = classes[architecture](
        model256_path=model_config["pretrained_encoder"],
        num_nuclei_classes=int(data_config["num_nuclei_classes"]),
        num_tissue_classes=int(data_config["num_tissue_classes"]),
        drop_rate=float(training_config.get("drop_rate", 0.0)),
        attn_drop_rate=float(training_config.get("attn_drop_rate", 0.0)),
        drop_path_rate=float(training_config.get("drop_path_rate", 0.0)),
        regression_loss=bool(model_config.get("regression_loss", False)),
    )
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    return model.to(device).eval(), checkpoint


def valid_points(
    instance_map: np.ndarray, valid_mask: np.ndarray
) -> list[tuple[float, float]]:
    return [
        (float(row), float(column))
        for row, column in instance_centroids(instance_map)
        if valid_mask[row, column]
    ]


def write_jsonl(path: Path, records: list[dict[str, float | str]]) -> None:
    path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )


def git_head(repository: Path) -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repository, text=True
    ).strip()


def main() -> None:
    args = parse_args()
    external_root = args.external_root.resolve()
    with args.config.resolve().open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    device = torch.device(args.device)
    model, checkpoint = load_cellvit(
        external_root,
        config,
        args.checkpoint.resolve(),
        device,
    )
    dataset = ManifestTaskDataset(
        args.manifest.resolve(),
        args.split,
        operations=["segmentation"],
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.num_workers > 0,
    )

    task_records: list[dict[str, float | str]] = []
    instance_records: list[dict[str, float | str]] = []
    segmentation_sums: defaultdict[str, float] = defaultdict(float)
    detection_counts: defaultdict[str, float] = defaultdict(float)

    with torch.no_grad():
        for batch in loader:
            images = batch["image"].to(device, non_blocking=True)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=device.type == "cuda",
            ):
                predictions = model(images)
            predictions["nuclei_binary_map"] = torch.softmax(
                predictions["nuclei_binary_map"].float(), dim=1
            )
            predictions["nuclei_type_map"] = torch.softmax(
                predictions["nuclei_type_map"].float(), dim=1
            )
            predicted_instances, _ = model.calculate_instance_map(
                predictions, magnification=args.magnification
            )
            probabilities = predictions["nuclei_binary_map"][:, 1].cpu()
            predicted_instances = predicted_instances.numpy().astype(np.int32)
            valid_masks = batch["valid_mask"][:, 0].numpy().astype(bool)

            for index, sample_id in enumerate(batch["sample_id"]):
                reference = np.load(batch["label_path"][index], allow_pickle=False)
                valid_mask = valid_masks[index]
                segmentation = binary_segmentation_scores(
                    probabilities[index],
                    torch.from_numpy(reference > 0),
                    threshold=0.5,
                    valid_mask=torch.from_numpy(valid_mask),
                )
                for key, value in segmentation.items():
                    segmentation_sums[key] += value

                prediction = predicted_instances[index]
                predicted_points = valid_points(prediction, valid_mask)
                reference_points = valid_points(reference, valid_mask)
                detection = point_detection_scores(
                    predicted_points,
                    reference_points,
                    matching_radius=args.matching_radius,
                )
                for key in ("true_positive", "false_positive", "false_negative"):
                    detection_counts[key] += detection[key]

                task_records.extend(
                    [
                        {
                            "sample_id": sample_id,
                            "domain": batch["domain"][index],
                            "operation": "detection",
                            **detection,
                        },
                        {
                            "sample_id": sample_id,
                            "domain": batch["domain"][index],
                            "operation": "segmentation",
                            **segmentation,
                        },
                    ]
                )

                masked_prediction = prediction.copy()
                masked_reference = reference.copy()
                masked_prediction[~valid_mask] = 0
                masked_reference[~valid_mask] = 0
                scores = instance_scores(masked_reference, masked_prediction)
                instance_records.append(
                    {
                        "sample_id": sample_id,
                        "domain": batch["domain"][index],
                        **scores,
                    }
                )

    true_positive = detection_counts["true_positive"]
    false_positive = detection_counts["false_positive"]
    false_negative = detection_counts["false_negative"]
    precision = true_positive / max(true_positive + false_positive, 1.0)
    recall = true_positive / max(true_positive + false_negative, 1.0)
    detection_f1 = 2.0 * precision * recall / max(precision + recall, 1e-12)
    image_count = len(instance_records)
    task_summary = {
        "split": args.split,
        "images": image_count,
        "detection_precision": precision,
        "detection_recall": recall,
        "detection_f1": detection_f1,
        "segmentation_dice": segmentation_sums["dice"] / image_count,
        "segmentation_iou": segmentation_sums["iou"] / image_count,
        "segmentation_threshold": 0.5,
        "instance_postprocessing": "CellViT official HV postprocessor",
    }

    instance_true_positive = sum(record["true_positive"] for record in instance_records)
    instance_false_positive = sum(record["false_positive"] for record in instance_records)
    instance_false_negative = sum(record["false_negative"] for record in instance_records)
    matched_iou = sum(record["true_positive"] * record["sq"] for record in instance_records)
    global_dq = instance_true_positive / max(
        instance_true_positive + 0.5 * instance_false_positive + 0.5 * instance_false_negative,
        1.0,
    )
    global_sq = matched_iou / max(instance_true_positive, 1.0)
    instance_summary = {
        "split": args.split,
        "images": image_count,
        "mean_aji_plus": sum(record["aji_plus"] for record in instance_records) / image_count,
        "mean_pq": sum(record["pq"] for record in instance_records) / image_count,
        "global_dq": global_dq,
        "global_sq": global_sq,
        "global_pq": global_dq * global_sq,
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    instance_name = "test_instances.jsonl" if args.split == "test" else "ood_test_instances.jsonl"
    write_jsonl(args.output_dir / "per_image_tasks.jsonl", task_records)
    write_jsonl(args.output_dir / instance_name, instance_records)
    (args.output_dir / "task_summary.json").write_text(
        json.dumps(task_summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (args.output_dir / "instance_summary.json").write_text(
        json.dumps(instance_summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    metadata = {
        "method": "CellViT-256",
        "cellvit_git_commit": git_head(external_root),
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_epoch_index": int(checkpoint["epoch"]),
        "checkpoint_architecture": str(checkpoint["arch"]),
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "split": args.split,
        "manifest": str(args.manifest.resolve()),
        "images": image_count,
        "official_binary_threshold": 0.5,
        "matching_radius": args.matching_radius,
        "magnification": args.magnification,
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({**task_summary, **instance_summary, **metadata}, sort_keys=True))


if __name__ == "__main__":
    main()

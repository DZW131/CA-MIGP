from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


SEEDS = (17, 23, 42)
BASE_FAMILIES = (
    "pannuke_full_prompt",
    "pannuke_ablation_no_style",
    "pannuke_ablation_no_spatial",
    "pannuke_ablation_no_modulation",
    "pannuke_multihead_unet",
)
OPTIONAL_FAMILIES = (
    "pannuke_ablation_no_style_hed",
    "pannuke_full_prompt_hed",
)
MANIFEST_SHA256 = "2049e5d760805b7ed4c2aaff8b8ee2a1297c0607188a085b5d1b200f3c954b5c"
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)
SUMMARY_FILES = (
    "fold3_task_summary.json",
    "fold3_instance_summary.json",
    "nuinsseg_task_summary.json",
    "nuinsseg_instance_summary.json",
)
PER_IMAGE_FILES = {
    "frozen_test/per_image_tasks.jsonl": 5444,
    "frozen_test/test_instances.jsonl": 2722,
    "nuinsseg_ood/per_image_tasks.jsonl": 1330,
    "nuinsseg_ood/ood_test_instances.jsonl": 665,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit manuscript experiment artifacts")
    parser.add_argument("--verified-root", required=True, type=Path)
    parser.add_argument("--per-image-root", type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    if not path.is_file():
        raise ValueError(f"Missing artifact: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def audit_run(run_dir: Path, seed: int) -> None:
    summary = read_json(run_dir / "train_summary.json")
    require(summary.get("status") == "completed", f"Incomplete run: {run_dir.name}")
    require(summary.get("seed") == seed, f"Seed mismatch: {run_dir.name}")
    require(summary.get("epochs") == 50, f"Unexpected epoch count: {run_dir.name}")
    history = summary.get("history")
    require(isinstance(history, list) and len(history) == 50, f"Bad history: {run_dir.name}")
    require(summary.get("git_dirty") is False, f"Dirty training tree: {run_dir.name}")
    git_commit = summary.get("git_commit")
    require(isinstance(git_commit, str) and len(git_commit) == 40, f"Bad Git hash: {run_dir.name}")
    require(
        summary.get("manifest_sha256") == MANIFEST_SHA256,
        f"Manifest mismatch: {run_dir.name}",
    )
    require(int(summary.get("parameters", 0)) > 0, f"Missing parameters: {run_dir.name}")

    for task in ("detection", "segmentation"):
        threshold = read_json(run_dir / f"val_{task}_threshold.json")
        require(
            threshold.get("selection_split") == "val",
            f"Non-validation threshold selection: {run_dir.name}/{task}",
        )
        value = float(threshold.get("selected_threshold", math.nan))
        require(math.isfinite(value) and 0.0 < value < 1.0, f"Bad threshold: {run_dir.name}/{task}")

    merged: dict[str, object] = {}
    for name in SUMMARY_FILES:
        merged.update(read_json(run_dir / name))
    for metric in METRICS:
        value = float(merged.get(metric, math.nan))
        require(
            math.isfinite(value) and 0.0 <= value <= 1.0,
            f"Bad {metric} in {run_dir.name}",
        )


def count_lines(path: Path) -> int:
    if not path.is_file():
        raise ValueError(f"Missing per-image artifact: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return sum(1 for line in handle if line.strip())


def available_families(verified_root: Path) -> tuple[str, ...]:
    families = list(BASE_FAMILIES)
    for family in OPTIONAL_FAMILIES:
        exists = [
            (verified_root / f"{family}_seed{seed}" / "train_summary.json").is_file()
            for seed in SEEDS
        ]
        if any(exists) and not all(exists):
            raise ValueError(f"Incomplete optional family: {family}")
        if all(exists):
            families.append(family)
    return tuple(families)


def audit_per_image(per_image_root: Path, families: tuple[str, ...]) -> int:
    checked = 0
    for family in families:
        for seed in SEEDS:
            run_dir = per_image_root / f"{family}_seed{seed}"
            for relative_path, expected in PER_IMAGE_FILES.items():
                path = run_dir / relative_path
                actual = count_lines(path)
                require(actual == expected, f"Expected {expected} rows, found {actual}: {path}")
                checked += 1
    return checked


def audit_aggregates(verified_root: Path, families: tuple[str, ...]) -> None:
    aggregate_root = verified_root / "aggregate"
    expected_lengths = {
        "stain_robustness.json": 27,
    }
    for name, expected in expected_lengths.items():
        path = aggregate_root / name
        if not path.is_file():
            raise ValueError(f"Missing aggregate: {path}")
        records = json.loads(path.read_text(encoding="utf-8"))
        require(isinstance(records, list) and len(records) == expected, f"Bad aggregate: {path}")
    summary_path = aggregate_root / "multiseed_summary.json"
    comparisons_path = aggregate_root / "multiseed_comparisons.json"
    summaries = json.loads(summary_path.read_text(encoding="utf-8"))
    comparisons = json.loads(comparisons_path.read_text(encoding="utf-8"))
    require(
        isinstance(summaries, list) and len(summaries) == len(families) * 12,
        f"Bad aggregate: {summary_path}",
    )
    require(isinstance(comparisons, list) and len(comparisons) >= 48, f"Bad aggregate: {comparisons_path}")


def audit_paired_bootstraps(verified_root: Path, families: tuple[str, ...]) -> int:
    checked = 0
    for seed in SEEDS:
        run_dir = verified_root / f"pannuke_full_prompt_seed{seed}"
        for name in (
            "fold3_vs_no_style_paired_bootstrap.json",
            "nuinsseg_vs_no_style_paired_bootstrap.json",
        ):
            result = read_json(run_dir / name)
            require(result.get("replicates") == 10000, f"Bad bootstrap count: {run_dir.name}/{name}")
            require(result.get("seed") == 2026, f"Bad bootstrap seed: {run_dir.name}/{name}")
            checked += 1
        if "pannuke_ablation_no_style_hed" in families:
            for name in (
                "fold3_vs_no_style_hed_paired_bootstrap.json",
                "nuinsseg_vs_no_style_hed_paired_bootstrap.json",
            ):
                result = read_json(run_dir / name)
                require(result.get("replicates") == 10000, f"Bad bootstrap count: {run_dir.name}/{name}")
                require(result.get("seed") == 2026, f"Bad bootstrap seed: {run_dir.name}/{name}")
                checked += 1
        if "pannuke_full_prompt_hed" in families:
            hed_dir = verified_root / f"pannuke_full_prompt_hed_seed{seed}"
            for name in (
                "fold3_vs_no_style_hed_paired_bootstrap.json",
                "nuinsseg_vs_no_style_hed_paired_bootstrap.json",
                "fold3_vs_full_no_hed_paired_bootstrap.json",
                "nuinsseg_vs_full_no_hed_paired_bootstrap.json",
                "fold3_factorial_bootstrap.json",
                "nuinsseg_factorial_bootstrap.json",
            ):
                result = read_json(hed_dir / name)
                require(result.get("replicates") == 10000, f"Bad bootstrap count: {hed_dir.name}/{name}")
                require(result.get("seed") == 2026, f"Bad bootstrap seed: {hed_dir.name}/{name}")
                checked += 1
    return checked


def main() -> None:
    args = parse_args()
    families = available_families(args.verified_root)
    checked_runs = 0
    for family in families:
        for seed in SEEDS:
            audit_run(args.verified_root / f"{family}_seed{seed}", seed)
            checked_runs += 1
    audit_aggregates(args.verified_root, families)
    paired_bootstrap_files = audit_paired_bootstraps(args.verified_root, families)
    per_image_files = (
        audit_per_image(args.per_image_root, families) if args.per_image_root else 0
    )
    print(
        json.dumps(
            {
                "aggregate_files": 3,
                "families": families,
                "paired_bootstrap_files": paired_bootstrap_files,
                "per_image_files": per_image_files,
                "runs": checked_runs,
                "status": "passed",
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

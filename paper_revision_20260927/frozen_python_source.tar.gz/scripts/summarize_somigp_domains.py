from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, median, stdev

from bootstrap_ci import (
    grouped_records,
    load_jsonl,
    point_metrics,
    propagate_group_key,
)


SEEDS = (17, 23, 42)
FAMILIES = {
    "full": "pannuke_full_prompt",
    "somigp": "pannuke_somigp",
}
DATASETS = {
    "nuinsseg": ("nuinsseg_ood", "ood_test_instances.jsonl", "sample_id"),
    "cryonuseg": (
        "cryonuseg_ann1_round1",
        "ood_test_instances.jsonl",
        "domain",
    ),
}
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
    "mean_boundary_f1",
    "mean_count_absolute_error",
    "contact_instance_recall",
    "contact_pair_success_rate",
    "contact_pair_merge_rate",
)
LOWER_IS_BETTER = {"mean_count_absolute_error", "contact_pair_merge_rate"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize SO-MIGP effects by domain")
    parser.add_argument("--outputs-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def domain_scores(
    evaluation: Path,
    instance_file: str,
    group_key: str,
) -> list[dict[str, object]]:
    tasks = load_jsonl(evaluation / "per_image_tasks.jsonl")
    instances = load_jsonl(evaluation / instance_file)
    propagate_group_key(tasks, instances, group_key)
    propagate_group_key(instances, tasks, group_key)
    task_groups = grouped_records(tasks, group_key)
    instance_groups = grouped_records(instances, group_key)
    if set(task_groups) != set(instance_groups):
        raise ValueError(f"Task/instance groups differ: {evaluation}")
    return [
        {
            "group": group,
            "images": len(instance_groups[group]),
            **point_metrics(task_groups[group], instance_groups[group]),
        }
        for group in sorted(task_groups)
    ]


def collect(outputs_root: Path) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for family, stem in FAMILIES.items():
        for seed in SEEDS:
            run_dir = outputs_root / f"{stem}_seed{seed}"
            for dataset, (relative_dir, instance_file, group_key) in DATASETS.items():
                records.extend(
                    {
                        "family": family,
                        "seed": seed,
                        "dataset": dataset,
                        **row,
                    }
                    for row in domain_scores(
                        run_dir / relative_dir, instance_file, group_key
                    )
                )
    return records


def differences(records: list[dict[str, object]]) -> list[dict[str, object]]:
    index = {
        (
            str(record["family"]),
            int(record["seed"]),
            str(record["dataset"]),
            str(record["group"]),
        ): record
        for record in records
    }
    output: list[dict[str, object]] = []
    for seed in SEEDS:
        for dataset in DATASETS:
            groups = sorted(
                str(record["group"])
                for record in records
                if record["family"] == "somigp"
                and record["seed"] == seed
                and record["dataset"] == dataset
            )
            for group in groups:
                candidate = index[("somigp", seed, dataset, group)]
                reference = index[("full", seed, dataset, group)]
                output.append(
                    {
                        "comparison": "somigp_minus_full",
                        "seed": seed,
                        "dataset": dataset,
                        "group": group,
                        "images": candidate["images"],
                        **{
                            metric: float(candidate[metric]) - float(reference[metric])
                            for metric in METRICS
                        },
                    }
                )
    return output


def aggregate_domains(records: list[dict[str, object]]) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for dataset in DATASETS:
        groups = sorted(
            {str(record["group"]) for record in records if record["dataset"] == dataset}
        )
        for metric in METRICS:
            group_means = {
                group: mean(
                    float(record[metric])
                    for record in records
                    if record["dataset"] == dataset and record["group"] == group
                )
                for group in groups
            }
            values = list(group_means.values())
            better = (
                sum(value < 0.0 for value in values)
                if metric in LOWER_IS_BETTER
                else sum(value > 0.0 for value in values)
            )
            output.append(
                {
                    "comparison": "somigp_minus_full",
                    "dataset": dataset,
                    "metric": metric,
                    "groups": len(groups),
                    "better_groups": better,
                    "mean_unweighted_group_difference": mean(values),
                    "median_group_difference": median(values),
                    "sample_sd_across_groups": stdev(values),
                    "minimum_group_difference": min(values),
                    "maximum_group_difference": max(values),
                    "group_mean_differences": group_means,
                }
            )
    return output


def write_json(path: Path, records: list[dict[str, object]]) -> None:
    path.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, records: list[dict[str, object]]) -> None:
    flattened = [
        {key: value for key, value in record.items() if key != "group_mean_differences"}
        | (
            {"group_mean_differences": json.dumps(record["group_mean_differences"], sort_keys=True)}
            if "group_mean_differences" in record
            else {}
        )
        for record in records
    ]
    fieldnames = list(dict.fromkeys(key for record in flattened for key in record))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(flattened)


def main() -> None:
    args = parse_args()
    scores = collect(args.outputs_root)
    effects = differences(scores)
    aggregates = aggregate_domains(effects)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, rows in (
        ("somigp_domain_scores", scores),
        ("somigp_domain_differences", effects),
        ("somigp_domain_aggregate", aggregates),
    ):
        write_json(args.output_dir / f"{name}.json", rows)
        write_csv(args.output_dir / f"{name}.csv", rows)
    print(
        json.dumps(
            {
                "score_rows": len(scores),
                "difference_rows": len(effects),
                "aggregate_rows": len(aggregates),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

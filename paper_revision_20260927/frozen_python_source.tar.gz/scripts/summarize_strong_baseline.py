from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, stdev


SEEDS = (17, 23, 42)
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_pq",
)
PATHM_MODELS = {
    "full_prompt": "pannuke_full_prompt",
    "no_style": "pannuke_ablation_no_style",
    "multihead_unet": "pannuke_multihead_unet",
}
DATASETS = {
    "pannuke_fold3": (
        "fold3_task_summary.json",
        "fold3_instance_summary.json",
        "pannuke_fold3",
    ),
    "nuinsseg_ood": (
        "nuinsseg_task_summary.json",
        "nuinsseg_instance_summary.json",
        "nuinsseg_ood",
    ),
    "cryonuseg_ood": (
        "cryonuseg_ann1_round1_task_summary.json",
        "cryonuseg_ann1_round1_instance_summary.json",
        "cryonuseg_ann1_round1",
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize the pinned strong baseline")
    parser.add_argument("--verified-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def merged_metrics(task_path: Path, instance_path: Path) -> dict[str, float]:
    merged = {**read_json(task_path), **read_json(instance_path)}
    return {metric: float(merged[metric]) for metric in METRICS}


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    fieldnames = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    verified_root = args.verified_root.resolve()
    cellvit_root = verified_root / "cellvit256_fold1_baseline"
    values: dict[tuple[str, int, str, str], float] = {}
    score_rows: list[dict[str, object]] = []

    for model, family in PATHM_MODELS.items():
        for dataset, (task_name, instance_name, _) in DATASETS.items():
            per_metric: dict[str, list[float]] = {metric: [] for metric in METRICS}
            for seed in SEEDS:
                run = verified_root / f"{family}_seed{seed}"
                metrics = merged_metrics(run / task_name, run / instance_name)
                for metric, value in metrics.items():
                    values[(model, seed, dataset, metric)] = value
                    per_metric[metric].append(value)
            for metric, metric_values in per_metric.items():
                score_rows.append(
                    {
                        "model": model,
                        "dataset": dataset,
                        "metric": metric,
                        "runs": 3,
                        "mean": mean(metric_values),
                        "sample_sd": stdev(metric_values),
                        **{
                            f"seed_{seed}": value
                            for seed, value in zip(SEEDS, metric_values, strict=True)
                        },
                    }
                )

    cellvit_values: dict[tuple[str, str], float] = {}
    for dataset, (_, _, cellvit_label) in DATASETS.items():
        metrics = merged_metrics(
            cellvit_root / cellvit_label / "task_summary.json",
            cellvit_root / cellvit_label / "instance_summary.json",
        )
        for metric, value in metrics.items():
            cellvit_values[(dataset, metric)] = value
            score_rows.append(
                {
                    "model": "cellvit256_shared",
                    "dataset": dataset,
                    "metric": metric,
                    "runs": 1,
                    "mean": value,
                    "sample_sd": None,
                    "seed_19": value,
                }
            )

    difference_rows: list[dict[str, object]] = []
    difference_summary_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for metric in METRICS:
            differences = []
            for seed in SEEDS:
                difference = cellvit_values[(dataset, metric)] - values[
                    ("full_prompt", seed, dataset, metric)
                ]
                differences.append(difference)
                difference_rows.append(
                    {
                        "comparison": "cellvit256_shared_minus_full_prompt",
                        "dataset": dataset,
                        "metric": metric,
                        "full_prompt_seed": seed,
                        "difference": difference,
                    }
                )
            difference_summary_rows.append(
                {
                    "comparison": "cellvit256_shared_minus_full_prompt",
                    "dataset": dataset,
                    "metric": metric,
                    "comparisons": 3,
                    "mean_difference": mean(differences),
                    "sample_sd": stdev(differences),
                    "positive_comparisons": sum(value > 0 for value in differences),
                }
            )

    bootstrap_rows: list[dict[str, object]] = []
    for dataset, (_, _, cellvit_label) in DATASETS.items():
        for seed in SEEDS:
            result = read_json(
                cellvit_root
                / f"{cellvit_label}_vs_full_seed{seed}_paired_bootstrap.json"
            )
            metrics = result["metrics"]
            if not isinstance(metrics, dict):
                raise ValueError(f"Malformed bootstrap metrics: {dataset}/seed{seed}")
            for metric, interval in metrics.items():
                if not isinstance(interval, dict):
                    raise ValueError(f"Malformed bootstrap interval: {dataset}/{metric}")
                bootstrap_rows.append(
                    {
                        "comparison": "cellvit256_shared_minus_full_prompt",
                        "dataset": dataset,
                        "full_prompt_seed": seed,
                        "metric": metric,
                        "estimate": interval["estimate"],
                        "ci95_low": interval["ci95_low"],
                        "ci95_high": interval["ci95_high"],
                        "probability_greater_than_zero": interval[
                            "probability_greater_than_zero"
                        ],
                        "bootstrap_groups": result["groups"],
                        "bootstrap_replicates": result["replicates"],
                    }
                )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, rows in (
        ("strong_baseline_scores", score_rows),
        ("strong_baseline_differences", difference_rows),
        ("strong_baseline_difference_summary", difference_summary_rows),
        ("strong_baseline_bootstrap", bootstrap_rows),
    ):
        (args.output_dir / f"{name}.json").write_text(
            json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        write_csv(args.output_dir / f"{name}.csv", rows)
    print(
        json.dumps(
            {
                "bootstrap_rows": len(bootstrap_rows),
                "difference_rows": len(difference_rows),
                "difference_summary_rows": len(difference_summary_rows),
                "score_rows": len(score_rows),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

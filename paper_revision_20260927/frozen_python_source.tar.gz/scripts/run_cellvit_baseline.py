from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable

import torch
import yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run or resume the pinned CellViT baseline")
    parser.add_argument("--external-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--state", required=True, type=Path)
    parser.add_argument("--validation-batch-size", default=16, type=int)
    return parser.parse_args()


def cap_official_validation_batch(
    dataloader: Callable[..., Any], validation_batch_size: int
) -> Callable[..., Any]:
    if validation_batch_size <= 0:
        raise ValueError("validation batch size must be positive")

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        # The pinned PanNuke experiment hard-codes 128 only for validation.
        if kwargs.get("batch_size") == 128:
            kwargs["batch_size"] = validation_batch_size
        return dataloader(*args, **kwargs)

    return wrapped


def checkpoint_epoch(path: Path) -> int:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    return int(checkpoint["epoch"])


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def newest_run(log_root: Path, suffix: str) -> Path | None:
    candidates = sorted(
        (path for path in log_root.glob(f"*_{suffix}") if path.is_dir()),
        key=lambda path: path.stat().st_mtime,
    )
    return candidates[-1] if candidates else None


def git_head(repository: Path) -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repository, text=True
    ).strip()


def git_dirty(repository: Path) -> bool:
    return bool(
        subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=repository, text=True
        ).strip()
    )


def main() -> None:
    args = parse_args()
    external_root = args.external_root.resolve()
    config_path = args.config.resolve()
    state_path = args.state.resolve()
    repository_root = Path(__file__).resolve().parents[1]
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    epochs = int(config["training"]["epochs"])
    log_root = Path(config["logging"]["log_dir"])
    suffix = str(config["logging"]["log_comment"])
    log_root.mkdir(parents=True, exist_ok=True)
    Path(config["logging"]["wandb_dir"]).mkdir(parents=True, exist_ok=True)

    expected_commit = "05097e18e3d194a65121042f631b5753069f5ee3"
    actual_commit = git_head(external_root)
    if actual_commit != expected_commit:
        raise ValueError(f"CellViT commit mismatch: {actual_commit}")
    if git_dirty(external_root):
        raise ValueError("Pinned CellViT repository is dirty")
    pathm_commit = git_head(repository_root)
    if git_dirty(repository_root):
        raise ValueError("PathM wrapper repository is dirty at CellViT launch")
    source_sha256 = {
        path.name: file_sha256(path)
        for path in (
            config_path,
            Path(__file__).resolve(),
            repository_root / "scripts" / "evaluate_cellvit_baseline.py",
            repository_root / "scripts" / "run_cellvit_baseline_queue.sh",
        )
    }

    existing_run = newest_run(log_root, suffix)
    checkpoint = (
        existing_run / "checkpoints" / "latest_checkpoint.pth"
        if existing_run is not None
        else None
    )
    if checkpoint is not None and checkpoint.is_file() and checkpoint_epoch(checkpoint) >= epochs - 1:
        run_dir = existing_run
        elapsed = 0.0
    else:
        os.environ.setdefault("TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD", "1")
        sys.path.insert(0, str(external_root))
        from cell_segmentation.experiments import (  # noqa: PLC0415
            experiment_cellvit_pannuke,
        )

        experiment_cellvit_pannuke.DataLoader = cap_official_validation_batch(
            experiment_cellvit_pannuke.DataLoader, args.validation_batch_size
        )
        ExperimentCellVitPanNuke = experiment_cellvit_pannuke.ExperimentCellVitPanNuke

        started = time.time()
        experiment = ExperimentCellVitPanNuke(
            default_conf=config,
            checkpoint=checkpoint if checkpoint is not None and checkpoint.is_file() else None,
        )
        run_dir = Path(experiment.run_experiment()).resolve()
        elapsed = time.time() - started
        checkpoint = run_dir / "checkpoints" / "latest_checkpoint.pth"

    if checkpoint is None or not checkpoint.is_file():
        raise ValueError("CellViT training did not produce a latest checkpoint")
    best_checkpoint = run_dir / "checkpoints" / "model_best.pth"
    if not best_checkpoint.is_file():
        raise ValueError("CellViT training did not produce a validation-selected checkpoint")
    completed_epoch = checkpoint_epoch(checkpoint)
    if completed_epoch < epochs - 1:
        raise ValueError(f"CellViT stopped at epoch {completed_epoch + 1}/{epochs}")
    checkpoint_value = torch.load(checkpoint, map_location="cpu", weights_only=False)
    best_checkpoint_value = torch.load(best_checkpoint, map_location="cpu", weights_only=False)
    parameters = sum(value.numel() for value in checkpoint_value["model_state_dict"].values())
    state = {
        "status": "completed",
        "method": "CellViT-256",
        "run_dir": str(run_dir),
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": file_sha256(checkpoint),
        "best_checkpoint": str(best_checkpoint),
        "best_checkpoint_epoch_index": int(best_checkpoint_value["epoch"]),
        "best_checkpoint_sha256": file_sha256(best_checkpoint),
        "epochs": epochs,
        "completed_epoch_index": completed_epoch,
        "random_seed": int(config["random_seed"]),
        "parameters_in_state_dict": parameters,
        "duration_seconds_this_invocation": elapsed,
        "validation_batch_size": args.validation_batch_size,
        "upstream_validation_batch_size": 128,
        "cellvit_git_commit": actual_commit,
        "cellvit_git_dirty": False,
        "pathm_git_commit_at_launch": pathm_commit,
        "pathm_git_dirty_at_launch": False,
        "source_sha256_at_launch": source_sha256,
        "config": str(config_path),
    }
    state_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = state_path.with_suffix(state_path.suffix + ".tmp")
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(state_path)
    print(json.dumps(state, sort_keys=True))


if __name__ == "__main__":
    main()

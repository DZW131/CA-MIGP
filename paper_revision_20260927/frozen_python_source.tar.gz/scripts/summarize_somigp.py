from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, stdev


FAMILIES = {
    "full": ("pannuke_full_prompt", (17, 23, 42)),
    "somigp": ("pannuke_somigp", (17, 23, 42)),
    "gap": ("pannuke_gap_control", (17, 23, 42)),
    "no_orth": ("pannuke_geometry_no_orth", (17, 23, 42)),
    "no_contact": ("pannuke_geometry_no_contact", (17, 23, 42)),
    "constant_direction": ("pannuke_geometry_constant_direction", (17,)),
    "no_style_geometry": ("pannuke_no_style_geometry", (17,)),
    "no_style": ("pannuke_ablation_no_style", (17,)),
}
SPLITS = {
    "pannuke_fold3": (
        "frozen_test/task_summary.json",
        "frozen_test/test_instance_summary.json",
    ),
    "nuinsseg": (
        "nuinsseg_ood/task_summary.json",
        "nuinsseg_ood/ood_test_instance_summary.json",
    ),
    "cryonuseg_ann1_round1": (
        "cryonuseg_ann1_round1/task_summary.json",
        "cryonuseg_ann1_round1/ood_test_instance_summary.json",
    ),
    "cryonuseg_ann1_round2": (
        "cryonuseg_ann1_round2/task_summary.json",
        "cryonuseg_ann1_round2/ood_test_instance_summary.json",
    ),
    "cryonuseg_ann2": (
        "cryonuseg_ann2/task_summary.json",
        "cryonuseg_ann2/ood_test_instance_summary.json",
    ),
}
METRICS = (
    "detection_f1",
    "segmentation_dice",
    "segmentation_iou",
    "mean_aji_plus",
    "mean_pq",
    "global_dq",
    "global_sq",
    "global_pq",
    "mean_boundary_f1",
    "mean_count_absolute_error",
    "contact_instance_recall",
    "contact_pair_success_rate",
    "contact_pair_merge_rate",
)
LOWER_IS_BETTER = {"mean_count_absolute_error", "contact_pair_merge_rate"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize SO-MIGP experiment families")
    parser.add_argument("--outputs-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def collect_scores(outputs_root: Path) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for family, (stem, seeds) in FAMILIES.items():
        for seed in seeds:
            run_dir = outputs_root / f"{stem}_seed{seed}"
            for split, paths in SPLITS.items():
                task_path, instance_path = (run_dir / path for path in paths)
                if not task_path.is_file() or not instance_path.is_file():
                    continue
                merged = {**read_json(task_path), **read_json(instance_path)}
                record: dict[str, object] = {
                    "family": family,
                    "run_name": run_dir.name,
                    "seed": seed,
                    "split": split,
                }
                record.update(
                    {
                        metric: float(merged[metric])
                        for metric in METRICS
                        if metric in merged
                    }
                )
                records.append(record)
    return records


def comparisons(scores: list[dict[str, object]]) -> list[dict[str, object]]:
    indexed = {
        (str(record["family"]), int(record["seed"]), str(record["split"])): record
        for record in scores
    }
    output: list[dict[str, object]] = []
    for (family, seed, split), reference in indexed.items():
        candidate = indexed.get(("somigp", seed, split))
        if family == "somigp" or candidate is None:
            continue
        for metric in METRICS:
            if metric not in candidate or metric not in reference:
                continue
            output.append(
                {
                    "comparison": f"somigp_minus_{family}",
                    "candidate": "somigp",
                    "reference": family,
                    "seed": seed,
                    "split": split,
                    "metric": metric,
                    "difference": float(candidate[metric]) - float(reference[metric]),
                }
            )
    return output


def aggregate_scores(scores: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str, str], list[tuple[int, float]]] = {}
    for record in scores:
        for metric in METRICS:
            if metric not in record:
                continue
            key = (str(record["family"]), str(record["split"]), metric)
            grouped.setdefault(key, []).append(
                (int(record["seed"]), float(record[metric]))
            )
    output: list[dict[str, object]] = []
    for (family, split, metric), items in sorted(grouped.items()):
        items.sort()
        values = [value for _, value in items]
        output.append(
            {
                "family": family,
                "split": split,
                "metric": metric,
                "seeds": len(values),
                "mean": mean(values),
                "sample_sd": stdev(values) if len(values) > 1 else None,
                "minimum": min(values),
                "maximum": max(values),
                **{f"seed_{seed}": value for seed, value in items},
            }
        )
    return output


def aggregate(records: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, str, str], list[float]] = {}
    for record in records:
        key = (
            str(record["comparison"]),
            str(record["split"]),
            str(record["metric"]),
        )
        grouped.setdefault(key, []).append(float(record["difference"]))
    output: list[dict[str, object]] = []
    for (comparison, split, metric), values in sorted(grouped.items()):
        output.append(
            {
                "comparison": comparison,
                "split": split,
                "metric": metric,
                "seeds": len(values),
                "mean_difference": mean(values),
                "sample_sd": stdev(values) if len(values) > 1 else None,
                "positive_seeds": sum(value > 0.0 for value in values),
                "direction": "lower_is_better"
                if metric in LOWER_IS_BETTER
                else "higher_is_better",
                "better_seeds": sum(value < 0.0 for value in values)
                if metric in LOWER_IS_BETTER
                else sum(value > 0.0 for value in values),
            }
        )
    return output


def bootstrap_records(outputs_root: Path) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for seed in (17, 23, 42):
        run_dir = outputs_root / f"pannuke_somigp_seed{seed}"
        for split in (
            "frozen_test",
            "nuinsseg_ood",
            "cryonuseg_ann1_round1",
        ):
            prefix = f"{split}_vs_"
            suffix = "_paired_bootstrap.json"
            for path in sorted(run_dir.glob(f"{prefix}*{suffix}")):
                reference = path.name[len(prefix) : -len(suffix)]
                payload = read_json(path)
                metrics = payload.get("metrics", {})
                if not isinstance(metrics, dict):
                    raise ValueError(f"Invalid bootstrap metrics: {path}")
                for metric, values in metrics.items():
                    if not isinstance(values, dict):
                        raise ValueError(f"Invalid bootstrap metric: {path}:{metric}")
                    records.append(
                        {
                            "level": "within_seed",
                            "candidate": "somigp",
                            "seed": seed,
                            "split": split,
                            "reference": reference,
                            "metric": metric,
                            **values,
                        }
                    )

    hierarchical_root = outputs_root / "somigp_hierarchical_bootstrap"
    for path in sorted(hierarchical_root.glob("*.json")):
        payload = read_json(path)
        metrics = payload.get("metrics", {})
        if not isinstance(metrics, dict):
            raise ValueError(f"Invalid hierarchical metrics: {path}")
        split, _, reference = path.stem.partition("_vs_")
        for metric, values in metrics.items():
            if not isinstance(values, dict):
                raise ValueError(f"Invalid hierarchical metric: {path}:{metric}")
            row = {
                key: value
                for key, value in values.items()
                if key != "per_seed_difference"
            }
            per_seed = values.get("per_seed_difference", {})
            if isinstance(per_seed, dict):
                row.update(
                    {f"seed_{seed}": value for seed, value in per_seed.items()}
                )
            records.append(
                {
                    "level": "seed_then_group",
                    "candidate": "somigp",
                    "seed": None,
                    "split": split,
                    "reference": reference,
                    "metric": metric,
                    **row,
                }
            )
    run_dir = outputs_root / "pannuke_no_style_geometry_seed17"
    for split in (
        "frozen_test",
        "nuinsseg_ood",
        "cryonuseg_ann1_round1",
    ):
        path = run_dir / f"{split}_vs_no_style_paired_bootstrap.json"
        if not path.is_file():
            continue
        payload = read_json(path)
        metrics = payload.get("metrics", {})
        if not isinstance(metrics, dict):
            raise ValueError(f"Invalid bootstrap metrics: {path}")
        for metric, values in metrics.items():
            if not isinstance(values, dict):
                raise ValueError(f"Invalid bootstrap metric: {path}:{metric}")
            records.append(
                {
                    "level": "within_seed",
                    "candidate": "no_style_geometry",
                    "seed": 17,
                    "split": split,
                    "reference": "no_style",
                    "metric": metric,
                    **values,
                }
            )
    return records


def write_json(path: Path, records: list[dict[str, object]]) -> None:
    path.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, records: list[dict[str, object]]) -> None:
    fieldnames = list(dict.fromkeys(key for record in records for key in record))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    scores = collect_scores(args.outputs_root)
    score_aggregates = aggregate_scores(scores)
    differences = comparisons(scores)
    aggregates = aggregate(differences)
    bootstraps = bootstrap_records(args.outputs_root)
    for name, records in (
        ("somigp_scores", scores),
        ("somigp_score_aggregate", score_aggregates),
        ("somigp_differences", differences),
        ("somigp_aggregate", aggregates),
        ("somigp_bootstrap", bootstraps),
    ):
        write_json(args.output_dir / f"{name}.json", records)
        write_csv(args.output_dir / f"{name}.csv", records)
    print(
        json.dumps(
            {
                "aggregate_rows": len(aggregates),
                "bootstrap_rows": len(bootstraps),
                "difference_rows": len(differences),
                "score_aggregate_rows": len(score_aggregates),
                "score_rows": len(scores),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()

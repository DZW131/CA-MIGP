from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from bootstrap_ci import grouped_records, load_jsonl


CELLS = ("full", "no_style", "full_hed", "no_style_hed")
STATISTIC_KEYS = (
    "detection_true_positive",
    "detection_false_positive",
    "detection_false_negative",
    "segmentation_dice_sum",
    "segmentation_count",
    "instance_true_positive",
    "instance_false_positive",
    "instance_false_negative",
    "matched_iou",
    "aji_plus_sum",
    "pq_sum",
    "instance_count",
    "segmentation_iou_sum",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Paired bootstrap for a Style x HED design")
    for cell in CELLS:
        option = cell.replace("_", "-")
        parser.add_argument(f"--{option}-tasks", required=True, type=Path)
        parser.add_argument(f"--{option}-instances", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--cluster-key", choices=("domain", "sample_id"), default="sample_id")
    parser.add_argument("--replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def factorial_effects(cells: dict[str, dict[str, float]]) -> dict[str, dict[str, float]]:
    effects: dict[str, dict[str, float]] = {}
    for metric in cells["full"]:
        style_no_hed = cells["full"][metric] - cells["no_style"][metric]
        style_hed = cells["full_hed"][metric] - cells["no_style_hed"][metric]
        hed_no_style = cells["no_style_hed"][metric] - cells["no_style"][metric]
        hed_full = cells["full_hed"][metric] - cells["full"][metric]
        effects[metric] = {
            "style_effect_no_hed": style_no_hed,
            "style_effect_hed": style_hed,
            "hed_effect_no_style": hed_no_style,
            "hed_effect_full": hed_full,
            "style_by_hed_interaction": style_hed - style_no_hed,
        }
    return effects


def sufficient_statistics(
    task_records: list[dict[str, float | str]],
    instance_records: list[dict[str, float | str]],
) -> np.ndarray:
    detection = [record for record in task_records if record["operation"] == "detection"]
    segmentation = [
        record for record in task_records if record["operation"] == "segmentation"
    ]
    values = {
        "detection_true_positive": sum(float(row["true_positive"]) for row in detection),
        "detection_false_positive": sum(float(row["false_positive"]) for row in detection),
        "detection_false_negative": sum(float(row["false_negative"]) for row in detection),
        "segmentation_dice_sum": sum(float(row["dice"]) for row in segmentation),
        "segmentation_iou_sum": sum(float(row["iou"]) for row in segmentation),
        "segmentation_count": len(segmentation),
        "instance_true_positive": sum(
            float(row["true_positive"]) for row in instance_records
        ),
        "instance_false_positive": sum(
            float(row["false_positive"]) for row in instance_records
        ),
        "instance_false_negative": sum(
            float(row["false_negative"]) for row in instance_records
        ),
        "matched_iou": sum(
            float(row["true_positive"]) * float(row["sq"]) for row in instance_records
        ),
        "aji_plus_sum": sum(float(row["aji_plus"]) for row in instance_records),
        "pq_sum": sum(float(row["pq"]) for row in instance_records),
        "instance_count": len(instance_records),
    }
    return np.asarray([values[key] for key in STATISTIC_KEYS], dtype=np.float64)


def metrics_from_statistics(statistics: np.ndarray) -> dict[str, float]:
    values = dict(zip(STATISTIC_KEYS, statistics, strict=True))
    detection_precision = values["detection_true_positive"] / max(
        values["detection_true_positive"] + values["detection_false_positive"], 1.0
    )
    detection_recall = values["detection_true_positive"] / max(
        values["detection_true_positive"] + values["detection_false_negative"], 1.0
    )
    dq = values["instance_true_positive"] / max(
        values["instance_true_positive"]
        + 0.5 * values["instance_false_positive"]
        + 0.5 * values["instance_false_negative"],
        1.0,
    )
    sq = values["matched_iou"] / max(values["instance_true_positive"], 1.0)
    return {
        "detection_f1": 2.0
        * detection_precision
        * detection_recall
        / max(detection_precision + detection_recall, 1e-12),
        "segmentation_dice": values["segmentation_dice_sum"]
        / max(values["segmentation_count"], 1.0),
        "segmentation_iou": values["segmentation_iou_sum"]
        / max(values["segmentation_count"], 1.0),
        "mean_aji_plus": values["aji_plus_sum"] / max(values["instance_count"], 1.0),
        "mean_pq": values["pq_sum"] / max(values["instance_count"], 1.0),
        "global_dq": dq,
        "global_sq": sq,
        "global_pq": dq * sq,
    }


def main() -> None:
    args = parse_args()
    grouped: dict[str, dict[str, list[dict[str, float | str]]]] = {}
    for cell in CELLS:
        tasks = load_jsonl(getattr(args, f"{cell}_tasks"))
        instances = load_jsonl(getattr(args, f"{cell}_instances"))
        grouped[f"{cell}_tasks"] = grouped_records(tasks, args.cluster_key)
        grouped[f"{cell}_instances"] = grouped_records(instances, args.cluster_key)

    group_ids = sorted(set.intersection(*(set(records) for records in grouped.values())))
    if not group_ids:
        raise ValueError("No shared groups across the four factorial cells")
    for name, records in grouped.items():
        missing = set(records) - set(group_ids)
        if missing:
            raise ValueError(f"{name} has {len(missing)} groups absent from another input")

    statistics = {
        cell: np.stack(
            [
                sufficient_statistics(
                    grouped[f"{cell}_tasks"][group],
                    grouped[f"{cell}_instances"][group],
                )
                for group in group_ids
            ]
        )
        for cell in CELLS
    }
    point_cells = {
        cell: metrics_from_statistics(statistics[cell].sum(axis=0)) for cell in CELLS
    }
    point_effects = factorial_effects(point_cells)
    rng = np.random.default_rng(args.seed)
    samples: defaultdict[tuple[str, str], list[float]] = defaultdict(list)
    for _ in range(args.replicates):
        chosen = rng.integers(0, len(group_ids), size=len(group_ids))
        sampled_cells = {
            cell: metrics_from_statistics(statistics[cell][chosen].sum(axis=0))
            for cell in CELLS
        }
        for metric, effects in factorial_effects(sampled_cells).items():
            for effect, value in effects.items():
                samples[(metric, effect)].append(value)

    output = {
        "bootstrap_unit": args.cluster_key,
        "difference": "style_by_hed_factorial",
        "groups": len(group_ids),
        "replicates": args.replicates,
        "seed": args.seed,
        "metrics": {},
    }
    metrics_output: dict[str, object] = {}
    for metric, effects in point_effects.items():
        record: dict[str, object] = {cell: point_cells[cell][metric] for cell in CELLS}
        for effect, estimate in effects.items():
            distribution = np.asarray(samples[(metric, effect)])
            record[effect] = {
                "estimate": estimate,
                "ci95_low": float(np.percentile(distribution, 2.5)),
                "ci95_high": float(np.percentile(distribution, 97.5)),
                "probability_greater_than_zero": float(np.mean(distribution > 0.0)),
            }
        metrics_output[metric] = record
    output["metrics"] = metrics_output
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
